package com.pixelforge.editor

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** Opening / saving images and the layered ".pforge" project format. */
object ImageIO {

    /** Decode an image (honouring EXIF rotation) no larger than [maxDim] on its long side. */
    fun decode(ctx: Context, uri: Uri, maxDim: Int = Document.MAX_DIM): Bitmap {
        val cr = ctx.contentResolver
        val opts = BitmapFactory.Options()
        opts.inJustDecodeBounds = true
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        if (opts.outWidth <= 0 || opts.outHeight <= 0) throw IllegalArgumentException("Not an image")
        var sample = 1
        while (maxOf(opts.outWidth, opts.outHeight) / sample > maxDim) sample *= 2
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = sample
        o2.inPreferredConfig = Bitmap.Config.ARGB_8888
        var bmp = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
            ?: throw IllegalArgumentException("Could not read image")

        var orientation = ExifInterface.ORIENTATION_NORMAL
        try {
            cr.openInputStream(uri)?.use {
                orientation = ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            }
        } catch (_: Exception) {}
        val m = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> { m.postRotate(90f); m.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_TRANSVERSE -> { m.postRotate(270f); m.postScale(-1f, 1f) }
        }
        if (!m.isIdentity) {
            val r = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            if (r !== bmp) bmp.recycle()
            bmp = r
        }
        // make sure it is mutable ARGB_8888
        if (!bmp.isMutable || bmp.config != Bitmap.Config.ARGB_8888) {
            val c = bmp.copy(Bitmap.Config.ARGB_8888, true) ?: throw OutOfMemoryError()
            bmp.recycle()
            bmp = c
        }
        return bmp
    }

    fun documentFromBitmap(bmp: Bitmap): Document {
        val d = Document(bmp.width, bmp.height)
        d.layers.add(Layer(d.nextId(), "Background", bmp))
        d.active = 0
        return d
    }

    fun blankDocument(w: Int, h: Int, fill: Int): Document {
        val d = Document(w, h)
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        if (fill != 0) b.eraseColor(fill)
        d.layers.add(Layer(d.nextId(), "Background", b))
        d.active = 0
        return d
    }

    /** Fit an imported picture inside the document (never upscaled) and centre it on a transparent layer. */
    fun placeOnLayer(doc: Document, src: Bitmap): Bitmap {
        val out = Bitmap.createBitmap(doc.width, doc.height, Bitmap.Config.ARGB_8888)
        val s = minOf(1f, doc.width.toFloat() / src.width, doc.height.toFloat() / src.height)
        val m = Matrix()
        m.postScale(s, s)
        m.postTranslate((doc.width - src.width * s) / 2f, (doc.height - src.height * s) / 2f)
        val p = Paint(Paint.FILTER_BITMAP_FLAG)
        Canvas(out).drawBitmap(src, m, p)
        return out
    }

    // ---------------------------------------------------------------- export

    enum class Format(val label: String, val ext: String, val mime: String) {
        PNG("PNG (lossless, keeps transparency)", "png", "image/png"),
        JPEG("JPEG (small file)", "jpg", "image/jpeg"),
        WEBP("WebP (small, modern)", "webp", "image/webp")
    }

    fun flatBitmap(doc: Document, forJpeg: Boolean): Bitmap {
        val out = Bitmap.createBitmap(doc.width, doc.height, Bitmap.Config.ARGB_8888)
        if (forJpeg) out.eraseColor(Color.WHITE)
        Compositor.render(doc, out, clear = !forJpeg)
        return out
    }

    /** Saves to Pictures/PixelForge via MediaStore. Returns the content Uri. */
    fun export(ctx: Context, doc: Document, fmt: Format, quality: Int, baseName: String): Uri {
        val bmp = flatBitmap(doc, fmt == Format.JPEG)
        try {
            val cv = ContentValues()
            cv.put(MediaStore.Images.Media.DISPLAY_NAME, "$baseName.${fmt.ext}")
            cv.put(MediaStore.Images.Media.MIME_TYPE, fmt.mime)
            if (Build.VERSION.SDK_INT >= 29) {
                cv.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/PixelForge")
                cv.put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
                ?: throw java.io.IOException("Could not create the file")
            ctx.contentResolver.openOutputStream(uri)?.use { os ->
                val cf = when (fmt) {
                    Format.PNG -> Bitmap.CompressFormat.PNG
                    Format.JPEG -> Bitmap.CompressFormat.JPEG
                    Format.WEBP -> if (Build.VERSION.SDK_INT >= 30) Bitmap.CompressFormat.WEBP_LOSSY else @Suppress("DEPRECATION") Bitmap.CompressFormat.WEBP
                }
                if (!bmp.compress(cf, quality, os)) throw java.io.IOException("Compression failed")
            } ?: throw java.io.IOException("Could not open the file")
            if (Build.VERSION.SDK_INT >= 29) {
                val done = ContentValues()
                done.put(MediaStore.Images.Media.IS_PENDING, 0)
                ctx.contentResolver.update(uri, done, null, null)
            }
            return uri
        } finally {
            bmp.recycle()
        }
    }

    // ---------------------------------------------------------------- project (.pforge = zip of PNG layers + json)

    fun saveProject(ctx: Context, doc: Document, uri: Uri) {
        val os = ctx.contentResolver.openOutputStream(uri) ?: throw java.io.IOException("Could not open the file")
        ZipOutputStream(os.buffered()).use { zip ->
            val meta = JSONObject()
            meta.put("version", 1)
            meta.put("width", doc.width)
            meta.put("height", doc.height)
            meta.put("active", doc.active)
            val arr = JSONArray()
            for ((i, l) in doc.layers.withIndex()) {
                val o = JSONObject()
                o.put("name", l.name)
                o.put("visible", l.visible)
                o.put("opacity", l.opacity)
                o.put("blend", l.blend.name)
                o.put("file", "layer$i.png")
                l.text?.let { t ->
                    val to = JSONObject()
                    to.put("text", t.text); to.put("size", t.size.toDouble()); to.put("color", t.color)
                    to.put("bold", t.bold); to.put("italic", t.italic); to.put("family", t.family)
                    to.put("align", t.align); to.put("x", t.x.toDouble()); to.put("y", t.y.toDouble())
                    to.put("strokeW", t.strokeW.toDouble()); to.put("strokeColor", t.strokeColor)
                    to.put("shadow", t.shadow); to.put("spacing", t.spacing.toDouble())
                    o.put("textData", to)
                }
                arr.put(o)
                zip.putNextEntry(ZipEntry("layer$i.png"))
                val bos = ByteArrayOutputStream()
                l.bitmap.compress(Bitmap.CompressFormat.PNG, 100, bos)
                zip.write(bos.toByteArray())
                zip.closeEntry()
            }
            meta.put("layers", arr)
            zip.putNextEntry(ZipEntry("project.json"))
            zip.write(meta.toString().toByteArray(Charsets.UTF_8))
            zip.closeEntry()
        }
        doc.dirty = false
    }

    /** True when the stream starts with the zip signature "PK". */
    fun looksLikeProject(ctx: Context, uri: Uri): Boolean {
        return try {
            ctx.contentResolver.openInputStream(uri)?.use { it.read() == 0x50 && it.read() == 0x4B } ?: false
        } catch (_: Exception) { false }
    }

    fun loadProject(ctx: Context, uri: Uri): Document {
        val files = HashMap<String, ByteArray>()
        val ins: InputStream = ctx.contentResolver.openInputStream(uri) ?: throw java.io.IOException("Could not open the file")
        ZipInputStream(ins.buffered()).use { zip ->
            var e = zip.nextEntry
            while (e != null) {
                files[e.name] = zip.readBytes()
                e = zip.nextEntry
            }
        }
        val meta = JSONObject(String(files["project.json"] ?: throw IllegalArgumentException("Not a PixelForge project"), Charsets.UTF_8))
        val doc = Document(meta.getInt("width"), meta.getInt("height"))
        val arr = meta.getJSONArray("layers")
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val bytes = files[o.getString("file")] ?: continue
            val opts = BitmapFactory.Options()
            opts.inMutable = true
            opts.inPreferredConfig = Bitmap.Config.ARGB_8888
            var bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts) ?: continue
            if (bmp.width != doc.width || bmp.height != doc.height) {
                val fixed = Bitmap.createBitmap(doc.width, doc.height, Bitmap.Config.ARGB_8888)
                Canvas(fixed).drawBitmap(bmp, 0f, 0f, null)
                bmp = fixed
            }
            val layer = Layer(doc.nextId(), o.optString("name", "Layer"), bmp)
            layer.visible = o.optBoolean("visible", true)
            layer.opacity = o.optInt("opacity", 100)
            layer.blend = try { Blend.valueOf(o.optString("blend", "NORMAL")) } catch (_: Exception) { Blend.NORMAL }
            o.optJSONObject("textData")?.let { t ->
                layer.text = TextData(
                    text = t.optString("text", ""), size = t.optDouble("size", 100.0).toFloat(),
                    color = t.optInt("color", Color.WHITE), bold = t.optBoolean("bold", true),
                    italic = t.optBoolean("italic", false), family = t.optInt("family", 0),
                    align = t.optInt("align", 0), x = t.optDouble("x", 0.0).toFloat(), y = t.optDouble("y", 0.0).toFloat(),
                    strokeW = t.optDouble("strokeW", 0.0).toFloat(), strokeColor = t.optInt("strokeColor", Color.BLACK),
                    shadow = t.optBoolean("shadow", false), spacing = t.optDouble("spacing", 0.0).toFloat()
                )
            }
            doc.layers.add(layer)
        }
        if (doc.layers.isEmpty()) throw IllegalArgumentException("The project has no layers")
        doc.active = meta.optInt("active", 0).coerceIn(0, doc.layers.size - 1)
        return doc
    }
}
