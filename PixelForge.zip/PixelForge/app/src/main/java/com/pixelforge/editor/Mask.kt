package com.pixelforge.editor

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import java.nio.ByteBuffer

/**
 * A selection: one byte of coverage (0..255) per pixel. Treated as immutable once created,
 * so undo history can share it safely.
 */
class Mask(val w: Int, val h: Int, val a: ByteArray) {
    private var bmp: Bitmap? = null
    private var edge: Bitmap? = null
    private var boundsCache: Rect? = null
    private var boundsDone = false

    fun at(x: Int, y: Int): Int = a[y * w + x].toInt() and 0xFF

    /** ALPHA_8 bitmap view of the mask (for use as a shader / DST_IN mask). */
    fun bitmap(): Bitmap {
        bmp?.let { return it }
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ALPHA_8)
        val rb = b.rowBytes
        val buf: ByteArray
        if (rb == w) buf = a else {
            buf = ByteArray(rb * h)
            for (y in 0 until h) System.arraycopy(a, y * w, buf, y * rb, w)
        }
        b.copyPixelsFromBuffer(ByteBuffer.wrap(buf))
        bmp = b
        return b
    }

    /** Tight bounds of non-empty coverage, or null when nothing is selected. */
    fun bounds(): Rect? {
        if (boundsDone) return boundsCache
        var minX = w; var minY = h; var maxX = -1; var maxY = -1
        for (y in 0 until h) {
            val row = y * w
            for (x in 0 until w) {
                if (a[row + x].toInt() != 0) {
                    if (x < minX) minX = x
                    if (x > maxX) maxX = x
                    if (y < minY) minY = y
                    if (y > maxY) maxY = y
                }
            }
        }
        boundsCache = if (maxX < 0) null else Rect(minX, minY, maxX + 1, maxY + 1)
        boundsDone = true
        return boundsCache
    }

    fun isEmpty(): Boolean = bounds() == null

    /** Marching-ants style outline bitmap (ARGB) for display. */
    fun edges(): Bitmap {
        edge?.let { return it }
        val px = IntArray(w * h)
        for (y in 0 until h) {
            for (x in 0 until w) {
                val i = y * w + x
                if ((a[i].toInt() and 0xFF) < 128) continue
                val border = x == 0 || y == 0 || x == w - 1 || y == h - 1 ||
                        (a[i - 1].toInt() and 0xFF) < 128 || (a[i + 1].toInt() and 0xFF) < 128 ||
                        (a[i - w].toInt() and 0xFF) < 128 || (a[i + w].toInt() and 0xFF) < 128
                if (border && x > 0 && y > 0 && x < w - 1 && y < h - 1) {
                    px[i] = if (((x + y) / 4) % 2 == 0) -0x1000000 else -0x1
                } else if (x == 0 || y == 0 || x == w - 1 || y == h - 1) {
                    px[i] = if (((x + y) / 4) % 2 == 0) -0x1000000 else -0x1
                }
            }
        }
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        b.setPixels(px, 0, w, 0, 0, w, h)
        edge = b
        return b
    }

    fun inverted(): Mask {
        val o = ByteArray(a.size)
        for (i in a.indices) o[i] = (255 - (a[i].toInt() and 0xFF)).toByte()
        return Mask(w, h, o)
    }

    fun feathered(radius: Int): Mask {
        if (radius <= 0) return this
        return Mask(w, h, Fx.blurBytes(a, w, h, radius, 2))
    }

    fun grown(r: Int): Mask {
        if (r <= 0) return this
        return Mask(w, h, Fx.dilateBytes(a, w, h, r))
    }

    fun shrunk(r: Int): Mask {
        if (r <= 0) return this
        return inverted().grown(r).inverted()
    }

    companion object {
        fun full(w: Int, h: Int): Mask {
            val o = ByteArray(w * h)
            java.util.Arrays.fill(o, (-1).toByte())
            return Mask(w, h, o)
        }

        private fun readAlpha(b: Bitmap, w: Int, h: Int): ByteArray {
            val rb = b.rowBytes
            val buf = ByteBuffer.allocate(rb * h)
            b.copyPixelsToBuffer(buf)
            val raw = buf.array()
            if (rb == w) return raw
            val o = ByteArray(w * h)
            for (y in 0 until h) System.arraycopy(raw, y * rb, o, y * w, w)
            return o
        }

        fun fromPath(w: Int, h: Int, path: Path, stroke: Float = 0f): Mask {
            val b = Bitmap.createBitmap(w, h, Bitmap.Config.ALPHA_8)
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            p.color = -0x1
            if (stroke > 0f) {
                p.style = Paint.Style.STROKE
                p.strokeWidth = stroke
                p.strokeCap = Paint.Cap.ROUND
                p.strokeJoin = Paint.Join.ROUND
            } else p.style = Paint.Style.FILL
            Canvas(b).drawPath(path, p)
            val m = Mask(w, h, readAlpha(b, w, h))
            b.recycle()
            return m
        }

        fun rect(w: Int, h: Int, r: RectF): Mask {
            val p = Path()
            p.addRect(r, Path.Direction.CW)
            return fromPath(w, h, p)
        }

        fun ellipse(w: Int, h: Int, r: RectF): Mask {
            val p = Path()
            p.addOval(r, Path.Direction.CW)
            return fromPath(w, h, p)
        }

        fun combine(old: Mask?, add: Mask, mode: SelMode): Mask {
            if (old == null || mode == SelMode.NEW) {
                return if (mode == SelMode.SUBTRACT || mode == SelMode.INTERSECT) {
                    if (old == null) Mask(add.w, add.h, ByteArray(add.a.size)) else add
                } else add
            }
            val o = ByteArray(old.a.size)
            for (i in o.indices) {
                val x = old.a[i].toInt() and 0xFF
                val y = add.a[i].toInt() and 0xFF
                val v = when (mode) {
                    SelMode.ADD -> maxOf(x, y)
                    SelMode.SUBTRACT -> x * (255 - y) / 255
                    SelMode.INTERSECT -> minOf(x, y)
                    SelMode.NEW -> y
                }
                o[i] = v.toByte()
            }
            return Mask(old.w, old.h, o)
        }

        private fun near(c: Int, s: Int, tol: Int): Boolean {
            val da = Math.abs((c ushr 24) - (s ushr 24))
            if (da > tol) return false
            val dr = Math.abs(((c shr 16) and 255) - ((s shr 16) and 255))
            if (dr > tol) return false
            val dg = Math.abs(((c shr 8) and 255) - ((s shr 8) and 255))
            if (dg > tol) return false
            val db = Math.abs((c and 255) - (s and 255))
            return db <= tol
        }

        /** Magic wand / colour range selection. */
        fun wand(px: IntArray, w: Int, h: Int, sx: Int, sy: Int, tol: Int, contiguous: Boolean): Mask {
            val out = ByteArray(w * h)
            val on: Byte = -1
            val seed = px[sy * w + sx]
            if (!contiguous) {
                for (i in px.indices) if (near(px[i], seed, tol)) out[i] = on
            } else {
                val stack = IntArray(w * h)
                var sp = 0
                val start = sy * w + sx
                out[start] = on
                stack[sp++] = start
                while (sp > 0) {
                    val p = stack[--sp]
                    val x = p % w
                    val y = p / w
                    if (x > 0 && out[p - 1].toInt() == 0 && near(px[p - 1], seed, tol)) { out[p - 1] = on; stack[sp++] = p - 1 }
                    if (x < w - 1 && out[p + 1].toInt() == 0 && near(px[p + 1], seed, tol)) { out[p + 1] = on; stack[sp++] = p + 1 }
                    if (y > 0 && out[p - w].toInt() == 0 && near(px[p - w], seed, tol)) { out[p - w] = on; stack[sp++] = p - w }
                    if (y < h - 1 && out[p + w].toInt() == 0 && near(px[p + w], seed, tol)) { out[p + w] = on; stack[sp++] = p + w }
                }
            }
            // soften the stair-stepped edge slightly
            return Mask(w, h, Fx.blurBytes(out, w, h, 1, 1))
        }

        /**
         * Removes a plain background: finds the dominant colours along the image border and floods
         * inwards from the border. Returns the SUBJECT selection (background inverted).
         */
        fun autoSubject(px: IntArray, w: Int, h: Int, tol: Int): Mask {
            // collect dominant border colours (4 bits per channel buckets)
            val hist = HashMap<Int, Int>()
            fun add(c: Int) {
                val k = (((c shr 20) and 15) shl 8) or (((c shr 12) and 15) shl 4) or ((c shr 4) and 15)
                hist[k] = (hist[k] ?: 0) + 1
            }
            for (x in 0 until w) { add(px[x]); add(px[(h - 1) * w + x]) }
            for (y in 0 until h) { add(px[y * w]); add(px[y * w + w - 1]) }
            val seeds = hist.entries.sortedByDescending { it.value }.take(3).map {
                val k = it.key
                (0xFF shl 24) or ((((k shr 8) and 15) * 17) shl 16) or ((((k shr 4) and 15) * 17) shl 8) or ((k and 15) * 17)
            }
            val bg = ByteArray(w * h)
            val on: Byte = -1
            val stack = IntArray(w * h)
            var sp = 0
            fun matches(c: Int): Boolean {
                for (s in seeds) if (near(c, s, tol)) return true
                return false
            }
            fun seed(i: Int) {
                if (bg[i].toInt() == 0 && matches(px[i])) { bg[i] = on; stack[sp++] = i }
            }
            for (x in 0 until w) { seed(x); seed((h - 1) * w + x) }
            for (y in 0 until h) { seed(y * w); seed(y * w + w - 1) }
            while (sp > 0) {
                val p = stack[--sp]
                val x = p % w
                val y = p / w
                if (x > 0) seed(p - 1)
                if (x < w - 1) seed(p + 1)
                if (y > 0) seed(p - w)
                if (y < h - 1) seed(p + w)
            }
            val bgMask = Mask(w, h, Fx.blurBytes(bg, w, h, 1, 1))
            return bgMask.inverted()
        }
    }
}
