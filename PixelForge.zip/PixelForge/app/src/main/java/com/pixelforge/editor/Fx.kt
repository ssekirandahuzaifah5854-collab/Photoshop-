package com.pixelforge.editor

import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

/** One slider (or on/off switch) of an adjustment / filter dialog. */
class Param(val name: String, val min: Int, val max: Int, val def: Int, val toggle: Boolean = false)

/** An adjustment or filter: works on straight-alpha ARGB pixels and returns the result array. */
class FilterDef(
    val name: String,
    val params: List<Param>,
    val heavy: Boolean = false,
    val fn: (px: IntArray, w: Int, h: Int, p: IntArray) -> IntArray
)

object Fx {
    fun c8(v: Int): Int = if (v < 0) 0 else if (v > 255) 255 else v
    fun c8f(v: Float): Int = if (v <= 0f) 0 else if (v >= 255f) 255 else (v + 0.5f).toInt()
    fun luma(c: Int): Int = (((c shr 16) and 255) * 77 + ((c shr 8) and 255) * 150 + (c and 255) * 29) shr 8

    fun argb(a: Int, r: Int, g: Int, b: Int): Int = (a shl 24) or (r shl 16) or (g shl 8) or b

    // ------------------------------------------------------------------ blur primitives

    private fun boxPass(src: ByteArray, dst: ByteArray, w: Int, h: Int, r: Int, horizontal: Boolean) {
        val d = 2 * r + 1
        val len = if (horizontal) w else h
        val lines = if (horizontal) h else w
        val stride = if (horizontal) 1 else w
        val lineStep = if (horizontal) w else 1
        for (l in 0 until lines) {
            val base = l * lineStep
            var sum = 0
            for (i in -r..r) {
                val ci = if (i < 0) 0 else if (i > len - 1) len - 1 else i
                sum += src[base + ci * stride].toInt() and 0xFF
            }
            for (i in 0 until len) {
                dst[base + i * stride] = ((sum + (d shr 1)) / d).toByte()
                val addI = i + r + 1
                val subI = i - r
                val a = if (addI > len - 1) len - 1 else addI
                val s = if (subI < 0) 0 else subI
                sum += (src[base + a * stride].toInt() and 0xFF) - (src[base + s * stride].toInt() and 0xFF)
            }
        }
    }

    fun blurBytes(src: ByteArray, w: Int, h: Int, r: Int, passes: Int): ByteArray {
        if (r <= 0) return src
        var a = src.copyOf()
        var b = ByteArray(src.size)
        for (i in 0 until passes) {
            boxPass(a, b, w, h, r, true)
            boxPass(b, a, w, h, r, false)
        }
        return a
    }

    /** Square dilation (grow) of a coverage mask. */
    fun dilateBytes(src: ByteArray, w: Int, h: Int, r: Int): ByteArray {
        val tmp = ByteArray(src.size)
        val out = ByteArray(src.size)
        for (y in 0 until h) {
            val row = y * w
            var sum = 0
            for (i in -r..r) { val ci = if (i < 0) 0 else if (i > w - 1) w - 1 else i; sum += src[row + ci].toInt() and 0xFF }
            for (x in 0 until w) {
                tmp[row + x] = (if (sum > 255) 255 else sum).toByte()
                val a = min(w - 1, x + r + 1)
                val s = max(0, x - r)
                sum += (src[row + a].toInt() and 0xFF) - (src[row + s].toInt() and 0xFF)
            }
        }
        for (x in 0 until w) {
            var sum = 0
            for (i in -r..r) { val ci = if (i < 0) 0 else if (i > h - 1) h - 1 else i; sum += tmp[ci * w + x].toInt() and 0xFF }
            for (y in 0 until h) {
                out[y * w + x] = (if (sum > 255) 255 else sum).toByte()
                val a = min(h - 1, y + r + 1)
                val s = max(0, y - r)
                sum += (tmp[a * w + x].toInt() and 0xFF) - (tmp[s * w + x].toInt() and 0xFF)
            }
        }
        return out
    }

    /** Alpha-aware blur of ARGB pixels (premultiplied internally, so no dark fringes). */
    fun blurPx(px: IntArray, w: Int, h: Int, r: Int, passes: Int = 3): IntArray {
        if (r <= 0) return px.copyOf()
        val n = w * h
        val cr = ByteArray(n); val cg = ByteArray(n); val cb = ByteArray(n); val ca = ByteArray(n)
        for (i in 0 until n) {
            val c = px[i]
            val a = c ushr 24
            ca[i] = a.toByte()
            cr[i] = ((((c shr 16) and 255) * a + 127) / 255).toByte()
            cg[i] = ((((c shr 8) and 255) * a + 127) / 255).toByte()
            cb[i] = (((c and 255) * a + 127) / 255).toByte()
        }
        val tr = blurBytes(cr, w, h, r, passes)
        val tg = blurBytes(cg, w, h, r, passes)
        val tb = blurBytes(cb, w, h, r, passes)
        val ta = blurBytes(ca, w, h, r, passes)
        val out = IntArray(n)
        for (i in 0 until n) {
            val a = ta[i].toInt() and 255
            if (a == 0) { out[i] = 0; continue }
            val rr = min(255, (tr[i].toInt() and 255) * 255 / a)
            val gg = min(255, (tg[i].toInt() and 255) * 255 / a)
            val bb = min(255, (tb[i].toInt() and 255) * 255 / a)
            out[i] = argb(a, rr, gg, bb)
        }
        return out
    }

    /** result = lerp(orig, filtered, selection) per pixel. */
    fun maskBlend(orig: IntArray, res: IntArray, mask: ByteArray?): IntArray {
        if (mask == null) return res
        for (i in res.indices) {
            val m = mask[i].toInt() and 0xFF
            if (m == 255) continue
            if (m == 0) { res[i] = orig[i]; continue }
            val o = orig[i]; val f = res[i]
            val a = ((o ushr 24) * (255 - m) + (f ushr 24) * m) / 255
            val r = (((o shr 16) and 255) * (255 - m) + ((f shr 16) and 255) * m) / 255
            val g = (((o shr 8) and 255) * (255 - m) + ((f shr 8) and 255) * m) / 255
            val b = ((o and 255) * (255 - m) + (f and 255) * m) / 255
            res[i] = argb(a, r, g, b)
        }
        return res
    }

    // ------------------------------------------------------------------ tone

    fun applyLut(px: IntArray, lr: IntArray, lg: IntArray, lb: IntArray): IntArray {
        for (i in px.indices) {
            val c = px[i]
            px[i] = (c and -0x1000000) or (lr[(c shr 16) and 255] shl 16) or (lg[(c shr 8) and 255] shl 8) or lb[c and 255]
        }
        return px
    }

    fun applyLut(px: IntArray, l: IntArray): IntArray = applyLut(px, l, l, l)

    fun brightnessContrast(px: IntArray, b: Int, c: Int): IntArray {
        val cc = c.coerceIn(-100, 99)
        val f = tan((cc + 100) / 200.0 * Math.PI / 2.0).toFloat()
        val lut = IntArray(256) { v -> c8f((v - 127.5f) * f + 127.5f + b * 2.55f) }
        return applyLut(px, lut)
    }

    fun levels(px: IntArray, black: Int, white: Int, gamma: Float): IntArray {
        val bl = black.coerceIn(0, 254)
        val wh = white.coerceIn(bl + 1, 255)
        val lut = IntArray(256) { v ->
            val t = ((v - bl).toFloat() / (wh - bl)).coerceIn(0f, 1f)
            c8f(255f * t.pow(1f / gamma))
        }
        return applyLut(px, lut)
    }

    fun exposure(px: IntArray, stops: Float, gamma: Float): IntArray {
        val k = 2f.pow(stops)
        val lut = IntArray(256) { v ->
            val lin = (v / 255f).pow(2.2f) * k
            val s = lin.coerceIn(0f, 1f).pow(1f / 2.2f)
            c8f(255f * s.pow(1f / gamma))
        }
        return applyLut(px, lut)
    }

    fun curves(px: IntArray, sh: Int, mid: Int, hi: Int): IntArray {
        val xs = floatArrayOf(0f, 64f, 128f, 192f, 255f)
        val ys = floatArrayOf(0f, 64f + sh, 128f + mid, 192f + hi, 255f)
        // Catmull-Rom through the 5 control points
        val lut = IntArray(256)
        for (v in 0..255) {
            var seg = 0
            while (seg < 3 && v > xs[seg + 1]) seg++
            val p0 = if (seg == 0) 0 else seg - 1
            val p1 = seg
            val p2 = seg + 1
            val p3 = if (seg + 2 > 4) 4 else seg + 2
            val t = ((v - xs[p1]) / (xs[p2] - xs[p1])).coerceIn(0f, 1f)
            val m1 = (ys[p2] - ys[p0]) / (xs[p2] - xs[p0]) * (xs[p2] - xs[p1])
            val m2 = (ys[p3] - ys[p1]) / (xs[p3] - xs[p1]) * (xs[p2] - xs[p1])
            val t2 = t * t; val t3 = t2 * t
            val y = (2 * t3 - 3 * t2 + 1) * ys[p1] + (t3 - 2 * t2 + t) * m1 + (-2 * t3 + 3 * t2) * ys[p2] + (t3 - t2) * m2
            lut[v] = c8f(y)
        }
        return applyLut(px, lut)
    }

    fun shadowsHighlights(px: IntArray, s: Int, h: Int): IntArray {
        val lut = IntArray(256) { v ->
            val x = v / 255f
            val nx = x + (s / 100f) * 0.3f * (1 - x) * (1 - x) * (1 - x) + (h / 100f) * 0.3f * x * x * x
            c8f(nx * 255f)
        }
        return applyLut(px, lut)
    }

    fun autoEnhance(px: IntArray): IntArray {
        val hr = IntArray(256); val hg = IntArray(256); val hb = IntArray(256)
        var n = 0
        for (c in px) {
            if ((c ushr 24) < 8) continue
            hr[(c shr 16) and 255]++; hg[(c shr 8) and 255]++; hb[c and 255]++; n++
        }
        if (n == 0) return px
        fun range(hist: IntArray): IntArray {
            val cut = (n * 0.005f).toInt()
            var lo = 0; var acc = 0
            while (lo < 254 && acc + hist[lo] <= cut) { acc += hist[lo]; lo++ }
            var hi = 255; acc = 0
            while (hi > lo + 1 && acc + hist[hi] <= cut) { acc += hist[hi]; hi-- }
            return IntArray(256) { v -> c8f((v - lo) * 255f / max(1, hi - lo)) }
        }
        return applyLut(px, range(hr), range(hg), range(hb))
    }

    fun invert(px: IntArray): IntArray {
        for (i in px.indices) { val c = px[i]; px[i] = (c and -0x1000000) or (c.inv() and 0xFFFFFF) }
        return px
    }

    fun grayscale(px: IntArray, contrast: Int = 0): IntArray {
        val f = 1f + contrast / 100f
        for (i in px.indices) {
            val c = px[i]
            var l = luma(c)
            if (contrast != 0) l = c8f((l - 127.5f) * f + 127.5f)
            px[i] = (c and -0x1000000) or (l shl 16) or (l shl 8) or l
        }
        return px
    }

    fun sepia(px: IntArray, amount: Int): IntArray {
        val k = amount / 100f
        for (i in px.indices) {
            val c = px[i]
            val r = (c shr 16) and 255; val g = (c shr 8) and 255; val b = c and 255
            val sr = c8f(r * 0.393f + g * 0.769f + b * 0.189f)
            val sg = c8f(r * 0.349f + g * 0.686f + b * 0.168f)
            val sb = c8f(r * 0.272f + g * 0.534f + b * 0.131f)
            px[i] = argb(c ushr 24, (r + (sr - r) * k).roundToInt(), (g + (sg - g) * k).roundToInt(), (b + (sb - b) * k).roundToInt())
        }
        return px
    }

    fun threshold(px: IntArray, level: Int): IntArray {
        for (i in px.indices) {
            val c = px[i]
            val v = if (luma(c) >= level) 255 else 0
            px[i] = (c and -0x1000000) or (v shl 16) or (v shl 8) or v
        }
        return px
    }

    fun posterize(px: IntArray, levels: Int): IntArray {
        val n = max(2, levels)
        val lut = IntArray(256) { v -> c8f((v * (n - 1) / 255f).roundToInt() * 255f / (n - 1)) }
        return applyLut(px, lut)
    }

    fun temperature(px: IntArray, temp: Int, tint: Int): IntArray {
        val kr = 1f + temp * 0.004f
        val kb = 1f - temp * 0.004f
        val kg = 1f - tint * 0.003f
        val lr = IntArray(256) { c8f(it * kr) }
        val lg = IntArray(256) { c8f(it * kg) }
        val lb = IntArray(256) { c8f(it * kb) }
        return applyLut(px, lr, lg, lb)
    }

    fun vibrance(px: IntArray, v: Int): IntArray {
        val amt = v / 100f
        for (i in px.indices) {
            val c = px[i]
            val r = (c shr 16) and 255; val g = (c shr 8) and 255; val b = c and 255
            val mx = max(r, max(g, b)); val mn = min(r, min(g, b))
            val sat = (mx - mn) / 255f
            val k = amt * (1f - sat)
            val gray = luma(c)
            px[i] = argb(c ushr 24, c8f(r + (r - gray) * k), c8f(g + (g - gray) * k), c8f(b + (b - gray) * k))
        }
        return px
    }

    fun hsl(px: IntArray, dh: Float, ds: Float, dl: Float): IntArray {
        for (i in px.indices) {
            val c = px[i]
            val r = ((c shr 16) and 255) / 255f
            val g = ((c shr 8) and 255) / 255f
            val b = (c and 255) / 255f
            val mx = max(r, max(g, b)); val mn = min(r, min(g, b))
            var l = (mx + mn) / 2f
            val d = mx - mn
            var s = 0f
            var hh = 0f
            if (d > 1e-6f) {
                s = d / (1f - abs(2f * l - 1f))
                hh = when (mx) {
                    r -> 60f * (((g - b) / d) % 6f)
                    g -> 60f * ((b - r) / d + 2f)
                    else -> 60f * ((r - g) / d + 4f)
                }
                if (hh < 0f) hh += 360f
            }
            hh = (hh + dh) % 360f
            if (hh < 0f) hh += 360f
            s = if (ds > 0f) s + (1f - s) * ds else s * (1f + ds)
            l = if (dl > 0f) l + (1f - l) * dl else l * (1f + dl)
            val cc = (1f - abs(2f * l - 1f)) * s
            val x = cc * (1f - abs((hh / 60f) % 2f - 1f))
            val m = l - cc / 2f
            val rr: Float; val gg: Float; val bb: Float
            when {
                hh < 60f -> { rr = cc; gg = x; bb = 0f }
                hh < 120f -> { rr = x; gg = cc; bb = 0f }
                hh < 180f -> { rr = 0f; gg = cc; bb = x }
                hh < 240f -> { rr = 0f; gg = x; bb = cc }
                hh < 300f -> { rr = x; gg = 0f; bb = cc }
                else -> { rr = cc; gg = 0f; bb = x }
            }
            px[i] = argb(c ushr 24, c8f((rr + m) * 255f), c8f((gg + m) * 255f), c8f((bb + m) * 255f))
        }
        return px
    }

    // ------------------------------------------------------------------ filters

    fun unsharp(px: IntArray, w: Int, h: Int, amount: Float, radius: Int, threshold: Int = 0): IntArray {
        val bl = blurPx(px, w, h, radius, 2)
        for (i in px.indices) {
            val c = px[i]
            val o = bl[i]
            val r = (c shr 16) and 255; val g = (c shr 8) and 255; val b = c and 255
            val dr = r - ((o shr 16) and 255); val dg = g - ((o shr 8) and 255); val db = b - (o and 255)
            if (abs(dr) < threshold && abs(dg) < threshold && abs(db) < threshold) continue
            px[i] = argb(c ushr 24, c8f(r + dr * amount), c8f(g + dg * amount), c8f(b + db * amount))
        }
        return px
    }

    fun motionBlur(px: IntArray, w: Int, h: Int, dist: Int, angleDeg: Int): IntArray {
        val out = IntArray(px.size)
        val rad = Math.toRadians(angleDeg.toDouble())
        val dx = cos(rad).toFloat(); val dy = sin(rad).toFloat()
        val n = max(1, dist)
        val half = n / 2f
        for (y in 0 until h) {
            for (x in 0 until w) {
                var sa = 0; var sr = 0; var sg = 0; var sb = 0
                for (k in 0 until n) {
                    val t = k - half
                    var xx = (x + dx * t).roundToInt()
                    var yy = (y + dy * t).roundToInt()
                    if (xx < 0) xx = 0 else if (xx >= w) xx = w - 1
                    if (yy < 0) yy = 0 else if (yy >= h) yy = h - 1
                    val c = px[yy * w + xx]
                    val a = c ushr 24
                    sa += a
                    sr += ((c shr 16) and 255) * a
                    sg += ((c shr 8) and 255) * a
                    sb += (c and 255) * a
                }
                out[y * w + x] = if (sa == 0) 0 else argb(sa / n, sr / sa, sg / sa, sb / sa)
            }
        }
        return out
    }

    fun smooth(px: IntArray, w: Int, h: Int, radius: Int, thr: Int): IntArray {
        val out = IntArray(px.size)
        val wt = FloatArray(766) { d -> exp(-d.toFloat() / max(1, thr * 2)) }
        for (y in 0 until h) {
            for (x in 0 until w) {
                val c = px[y * w + x]
                val cr = (c shr 16) and 255; val cg = (c shr 8) and 255; val cb = c and 255
                var sw = 0f; var sr = 0f; var sg = 0f; var sb = 0f
                for (j in -radius..radius) {
                    val yy = min(h - 1, max(0, y + j))
                    for (i in -radius..radius) {
                        val xx = min(w - 1, max(0, x + i))
                        val q = px[yy * w + xx]
                        val qr = (q shr 16) and 255; val qg = (q shr 8) and 255; val qb = q and 255
                        val wgt = wt[abs(qr - cr) + abs(qg - cg) + abs(qb - cb)]
                        sw += wgt; sr += qr * wgt; sg += qg * wgt; sb += qb * wgt
                    }
                }
                out[y * w + x] = argb(c ushr 24, c8f(sr / sw), c8f(sg / sw), c8f(sb / sw))
            }
        }
        return out
    }

    fun noise(px: IntArray, amount: Int, mono: Boolean): IntArray {
        val rnd = java.util.Random(7)
        val k = amount * 2.55f
        for (i in px.indices) {
            val c = px[i]
            if ((c ushr 24) == 0) continue
            val n1 = (rnd.nextGaussian() * k * 0.5f).toFloat()
            val r = (c shr 16) and 255; val g = (c shr 8) and 255; val b = c and 255
            px[i] = if (mono) argb(c ushr 24, c8f(r + n1), c8f(g + n1), c8f(b + n1))
            else argb(c ushr 24, c8f(r + n1), c8f(g + (rnd.nextGaussian() * k * 0.5f).toFloat()), c8f(b + (rnd.nextGaussian() * k * 0.5f).toFloat()))
        }
        return px
    }

    fun pixelate(px: IntArray, w: Int, h: Int, size: Int): IntArray {
        val s = max(1, size)
        var by = 0
        while (by < h) {
            var bx = 0
            val bh = min(s, h - by)
            while (bx < w) {
                val bw = min(s, w - bx)
                var sa = 0; var sr = 0; var sg = 0; var sb = 0
                for (j in 0 until bh) for (i in 0 until bw) {
                    val c = px[(by + j) * w + bx + i]
                    val a = c ushr 24
                    sa += a; sr += ((c shr 16) and 255) * a; sg += ((c shr 8) and 255) * a; sb += (c and 255) * a
                }
                val cnt = bw * bh
                val v = if (sa == 0) 0 else argb(sa / cnt, sr / sa, sg / sa, sb / sa)
                for (j in 0 until bh) for (i in 0 until bw) px[(by + j) * w + bx + i] = v
                bx += s
            }
            by += s
        }
        return px
    }

    fun vignette(px: IntArray, w: Int, h: Int, amount: Int, size: Int): IntArray {
        val cx = w / 2f; val cy = h / 2f
        val maxD = sqrt(cx * cx + cy * cy)
        val inner = size / 100f * 0.9f
        val a = amount / 100f
        for (y in 0 until h) {
            for (x in 0 until w) {
                val d = sqrt((x - cx) * (x - cx) + (y - cy) * (y - cy)) / maxD
                var t = ((d - inner) / max(0.05f, 1f - inner)).coerceIn(0f, 1f)
                t = t * t * (3f - 2f * t)
                val c = px[y * w + x]
                val r = (c shr 16) and 255; val g = (c shr 8) and 255; val b = c and 255
                val nr: Int; val ng: Int; val nb: Int
                if (a >= 0f) {
                    val f = 1f - a * t
                    nr = c8f(r * f); ng = c8f(g * f); nb = c8f(b * f)
                } else {
                    val f = -a * t
                    nr = c8f(r + (255 - r) * f); ng = c8f(g + (255 - g) * f); nb = c8f(b + (255 - b) * f)
                }
                px[y * w + x] = argb(c ushr 24, nr, ng, nb)
            }
        }
        return px
    }

    fun softGlow(px: IntArray, w: Int, h: Int, radius: Int, amount: Int): IntArray {
        val bl = blurPx(px, w, h, radius, 3)
        val k = amount / 100f
        for (i in px.indices) {
            val c = px[i]; val o = bl[i]
            val r = (c shr 16) and 255; val g = (c shr 8) and 255; val b = c and 255
            val br = ((o shr 16) and 255) * k; val bg = ((o shr 8) and 255) * k; val bb = (o and 255) * k
            px[i] = argb(c ushr 24,
                c8f(255f - (255f - r) * (255f - br) / 255f),
                c8f(255f - (255f - g) * (255f - bg) / 255f),
                c8f(255f - (255f - b) * (255f - bb) / 255f))
        }
        return px
    }

    fun emboss(px: IntArray, w: Int, h: Int, strength: Int): IntArray {
        val out = IntArray(px.size)
        val k = strength / 50f
        for (y in 0 until h) {
            for (x in 0 until w) {
                val a = px[max(0, y - 1) * w + max(0, x - 1)]
                val b = px[min(h - 1, y + 1) * w + min(w - 1, x + 1)]
                val c = px[y * w + x]
                val dr = (((b shr 16) and 255) - ((a shr 16) and 255)) * k
                val dg = (((b shr 8) and 255) - ((a shr 8) and 255)) * k
                val db = ((b and 255) - (a and 255)) * k
                out[y * w + x] = argb(c ushr 24, c8f(128f + dr), c8f(128f + dg), c8f(128f + db))
            }
        }
        return out
    }

    fun edges(px: IntArray, w: Int, h: Int, invert: Boolean): IntArray {
        val out = IntArray(px.size)
        val l = IntArray(px.size) { luma(px[it]) }
        for (y in 0 until h) {
            val y0 = max(0, y - 1) * w; val y1 = y * w; val y2 = min(h - 1, y + 1) * w
            for (x in 0 until w) {
                val x0 = max(0, x - 1); val x2 = min(w - 1, x + 1)
                val gx = -l[y0 + x0] + l[y0 + x2] - 2 * l[y1 + x0] + 2 * l[y1 + x2] - l[y2 + x0] + l[y2 + x2]
                val gy = -l[y0 + x0] - 2 * l[y0 + x] - l[y0 + x2] + l[y2 + x0] + 2 * l[y2 + x] + l[y2 + x2]
                var v = c8f(sqrt((gx * gx + gy * gy).toFloat()))
                if (invert) v = 255 - v
                out[y1 + x] = argb(px[y1 + x] ushr 24, v, v, v)
            }
        }
        return out
    }
}

object Filters {
    private fun p(name: String, min: Int, max: Int, def: Int) = Param(name, min, max, def)

    val adjustments: List<FilterDef> = listOf(
        FilterDef("Auto Enhance", emptyList()) { px, _, _, _ -> Fx.autoEnhance(px) },
        FilterDef("Brightness / Contrast", listOf(p("Brightness", -100, 100, 0), p("Contrast", -100, 100, 0))) { px, _, _, q ->
            Fx.brightnessContrast(px, q[0], q[1])
        },
        FilterDef("Exposure", listOf(p("Exposure", -300, 300, 0), p("Gamma", 30, 300, 100))) { px, _, _, q ->
            Fx.exposure(px, q[0] / 100f, q[1] / 100f)
        },
        FilterDef("Levels", listOf(p("Black point", 0, 254, 0), p("White point", 1, 255, 255), p("Gamma", 20, 300, 100))) { px, _, _, q ->
            Fx.levels(px, q[0], q[1], q[2] / 100f)
        },
        FilterDef("Curves", listOf(p("Shadows", -64, 64, 0), p("Midtones", -64, 64, 0), p("Highlights", -64, 64, 0))) { px, _, _, q ->
            Fx.curves(px, q[0], q[1], q[2])
        },
        FilterDef("Shadows / Highlights", listOf(p("Shadows", -100, 100, 40), p("Highlights", -100, 100, -30))) { px, _, _, q ->
            Fx.shadowsHighlights(px, q[0], q[1])
        },
        FilterDef("Hue / Saturation", listOf(p("Hue", -180, 180, 0), p("Saturation", -100, 100, 0), p("Lightness", -100, 100, 0))) { px, _, _, q ->
            Fx.hsl(px, q[0].toFloat(), q[1] / 100f, q[2] / 100f)
        },
        FilterDef("Vibrance", listOf(p("Vibrance", -100, 100, 50))) { px, _, _, q -> Fx.vibrance(px, q[0]) },
        FilterDef("Temperature / Tint", listOf(p("Temperature", -100, 100, 0), p("Tint", -100, 100, 0))) { px, _, _, q ->
            Fx.temperature(px, q[0], q[1])
        },
        FilterDef("Black & White", listOf(p("Contrast", -50, 50, 0))) { px, _, _, q -> Fx.grayscale(px, q[0]) },
        FilterDef("Sepia", listOf(p("Amount", 0, 100, 100))) { px, _, _, q -> Fx.sepia(px, q[0]) },
        FilterDef("Invert", emptyList()) { px, _, _, _ -> Fx.invert(px) },
        FilterDef("Threshold", listOf(p("Level", 0, 255, 128))) { px, _, _, q -> Fx.threshold(px, q[0]) },
        FilterDef("Posterize", listOf(p("Levels", 2, 16, 4))) { px, _, _, q -> Fx.posterize(px, q[0]) }
    )

    val filters: List<FilterDef> = listOf(
        FilterDef("Gaussian Blur", listOf(p("Radius", 1, 60, 8))) { px, w, h, q -> Fx.blurPx(px, w, h, q[0], 3) },
        FilterDef("Motion Blur", listOf(p("Distance", 1, 80, 20), p("Angle", 0, 179, 0)), heavy = true) { px, w, h, q ->
            Fx.motionBlur(px, w, h, q[0], q[1])
        },
        FilterDef("Sharpen", listOf(p("Amount", 1, 300, 100), p("Radius", 1, 10, 2))) { px, w, h, q ->
            Fx.unsharp(px, w, h, q[0] / 100f, q[1], 0)
        },
        FilterDef("Clarity", listOf(p("Amount", -100, 100, 40))) { px, w, h, q ->
            val r = max(2, min(w, h) / 40)
            Fx.unsharp(px, w, h, q[0] / 100f, r, 0)
        },
        FilterDef("Smooth / Reduce Noise", listOf(p("Radius", 1, 5, 2), p("Threshold", 5, 120, 30)), heavy = true) { px, w, h, q ->
            Fx.smooth(px, w, h, q[0], q[1])
        },
        FilterDef("Add Noise", listOf(p("Amount", 1, 100, 20), Param("Monochrome", 0, 1, 1, toggle = true))) { px, _, _, q ->
            Fx.noise(px, q[0], q[1] == 1)
        },
        FilterDef("Pixelate", listOf(p("Cell size", 2, 80, 10))) { px, w, h, q -> Fx.pixelate(px, w, h, q[0]) },
        FilterDef("Vignette", listOf(p("Amount", -100, 100, 50), p("Size", 10, 100, 55))) { px, w, h, q ->
            Fx.vignette(px, w, h, q[0], q[1])
        },
        FilterDef("Soft Glow", listOf(p("Radius", 1, 40, 12), p("Amount", 0, 100, 50))) { px, w, h, q ->
            Fx.softGlow(px, w, h, q[0], q[1])
        },
        FilterDef("Emboss", listOf(p("Strength", 1, 100, 50))) { px, w, h, q -> Fx.emboss(px, w, h, q[0]) },
        FilterDef("Find Edges", listOf(Param("Invert", 0, 1, 0, toggle = true))) { px, w, h, q ->
            Fx.edges(px, w, h, q[0] == 1)
        }
    )
}
