package com.pixelforge.editor

import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

/** Small hand-rolled UI toolkit (no AppCompat / Material dependency needed). */
object UiColors {
    val BG = 0xFF17171B.toInt()
    val PANEL = 0xFF1F1F25.toInt()
    val CARD = 0xFF2C2C35.toInt()
    val CARD_HI = 0xFF3A3A46.toInt()
    val ACCENT = 0xFF31A8FF.toInt()
    val TEXT = 0xFFEDEDF2.toInt()
    val DIM = 0xFF9B9BA8.toInt()
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

fun Context.roundBg(color: Int, radiusDp: Int = 8, strokeColor: Int = 0, strokeDp: Int = 0): GradientDrawable {
    val g = GradientDrawable()
    g.setColor(color)
    g.cornerRadius = dp(radiusDp).toFloat()
    if (strokeDp > 0) g.setStroke(dp(strokeDp), strokeColor)
    return g
}

fun Context.label(s: String, sizeSp: Float = 13f, color: Int = UiColors.TEXT, bold: Boolean = false): TextView {
    val t = TextView(this)
    t.text = s
    t.textSize = sizeSp
    t.setTextColor(color)
    if (bold) t.setTypeface(t.typeface, android.graphics.Typeface.BOLD)
    return t
}

fun Context.button(s: String, filled: Boolean = false, onClick: () -> Unit): TextView {
    val t = label(s, 13f, if (filled) Color.WHITE else UiColors.TEXT, true)
    t.gravity = Gravity.CENTER
    t.setPadding(dp(14), dp(9), dp(14), dp(9))
    t.background = roundBg(if (filled) UiColors.ACCENT else UiColors.CARD, 8)
    t.setOnClickListener { onClick() }
    return t
}

fun lp(w: Int, h: Int, weight: Float = 0f): LinearLayout.LayoutParams = LinearLayout.LayoutParams(w, h, weight)

fun Context.hbox(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
fun Context.vbox(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

fun Context.spacer(wDp: Int = 6, hDp: Int = 6): View = View(this).apply { layoutParams = lp(dp(wDp), dp(hDp)) }

/** Horizontally scrollable row of mutually exclusive chips. */
fun Context.chips(options: List<String>, selected: Int, onSelect: (Int) -> Unit): HorizontalScrollView {
    val sv = HorizontalScrollView(this)
    sv.isHorizontalScrollBarEnabled = false
    val row = hbox()
    sv.addView(row)
    val views = ArrayList<TextView>()
    fun style(sel: Int) {
        for ((i, v) in views.withIndex()) {
            val on = i == sel
            v.background = roundBg(if (on) UiColors.ACCENT else UiColors.CARD, 16)
            v.setTextColor(if (on) Color.WHITE else UiColors.TEXT)
        }
    }
    for ((i, o) in options.withIndex()) {
        val t = label(o, 12f)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(12), dp(6), dp(12), dp(6))
        t.setOnClickListener { style(i); onSelect(i) }
        val p = lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        p.rightMargin = dp(6)
        row.addView(t, p)
        views.add(t)
    }
    style(selected)
    return sv
}

/** On/off chip. */
fun Context.toggleChip(text: String, on: Boolean, onChange: (Boolean) -> Unit): TextView {
    val t = label(text, 12f)
    t.gravity = Gravity.CENTER
    t.setPadding(dp(12), dp(6), dp(12), dp(6))
    var state = on
    fun style() {
        t.background = roundBg(if (state) UiColors.ACCENT else UiColors.CARD, 16)
        t.setTextColor(if (state) Color.WHITE else UiColors.TEXT)
    }
    style()
    t.setOnClickListener { state = !state; style(); onChange(state) }
    return t
}

/** Label + slider in one cell. */
fun Context.sliderCell(
    name: String, min: Int, max: Int, value: Int,
    fmt: (Int) -> String = { it.toString() },
    onStart: (() -> Unit)? = null,
    onStop: (() -> Unit)? = null,
    onChange: (Int) -> Unit
): LinearLayout {
    val col = vbox()
    val lab = label("$name: ${fmt(value)}", 12f, UiColors.DIM)
    val sb = SeekBar(this)
    sb.max = max - min
    sb.progress = (value - min).coerceIn(0, max - min)
    sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
            val v = p + min
            lab.text = "$name: ${fmt(v)}"
            if (fromUser) onChange(v)
        }
        override fun onStartTrackingTouch(s: SeekBar) { onStart?.invoke() }
        override fun onStopTrackingTouch(s: SeekBar) { onStop?.invoke() }
    })
    col.addView(lab)
    col.addView(sb, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    return col
}

/** Puts the views side by side with equal width. */
fun Context.cells(vararg v: View): LinearLayout {
    val r = hbox()
    for ((i, x) in v.withIndex()) {
        val p = lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        if (i > 0) p.leftMargin = dp(10)
        r.addView(x, p)
    }
    return r
}

fun Context.toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

object Dialogs {

    fun confirm(act: Activity, msg: String, yes: String = "Yes", onYes: () -> Unit) {
        AlertDialog.Builder(act, android.R.style.Theme_Material_Dialog_Alert)
            .setMessage(msg)
            .setPositiveButton(yes) { _, _ -> onYes() }
            .setNegativeButton("Cancel", null)
            .show()
    }

    fun choose(act: Activity, title: String, items: List<String>, onPick: (Int) -> Unit) {
        AlertDialog.Builder(act, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle(title)
            .setItems(items.toTypedArray()) { _, i -> onPick(i) }
            .show()
    }

    fun inputText(act: Activity, title: String, initial: String, onOk: (String) -> Unit) {
        val et = EditText(act)
        et.setText(initial)
        et.setSingleLine(true)
        et.setSelectAllOnFocus(true)
        et.setTextColor(UiColors.TEXT)
        val box = act.vbox()
        box.setPadding(act.dp(20), act.dp(8), act.dp(20), 0)
        box.addView(et)
        AlertDialog.Builder(act, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle(title)
            .setView(box)
            .setPositiveButton("OK") { _, _ -> onOk(et.text.toString()) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    fun askNumber(act: Activity, title: String, min: Int, max: Int, def: Int, unit: String = "", onOk: (Int) -> Unit) {
        var v = def
        val box = act.vbox()
        box.setPadding(act.dp(20), act.dp(8), act.dp(20), 0)
        box.addView(act.sliderCell(title, min, max, def, { "$it$unit" }) { v = it })
        AlertDialog.Builder(act, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle(title)
            .setView(box)
            .setPositiveButton("OK") { _, _ -> onOk(v) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    /** Two numeric fields (width x height). */
    fun askSize(act: Activity, title: String, w: Int, h: Int, keepAspect: Boolean, onOk: (Int, Int) -> Unit) {
        val ew = EditText(act); val eh = EditText(act)
        for (e in listOf(ew, eh)) {
            e.inputType = InputType.TYPE_CLASS_NUMBER
            e.setSingleLine(true)
            e.setTextColor(UiColors.TEXT)
            e.gravity = Gravity.CENTER
        }
        ew.setText(w.toString()); eh.setText(h.toString())
        val ratio = w.toFloat() / h
        var busy = false
        if (keepAspect) {
            ew.addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) {
                    if (busy) return
                    val n = s.toString().toIntOrNull() ?: return
                    busy = true; eh.setText(Math.max(1, Math.round(n / ratio)).toString()); busy = false
                }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
            eh.addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) {
                    if (busy) return
                    val n = s.toString().toIntOrNull() ?: return
                    busy = true; ew.setText(Math.max(1, Math.round(n * ratio)).toString()); busy = false
                }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        }
        val row = act.hbox()
        row.setPadding(act.dp(20), act.dp(8), act.dp(20), 0)
        row.addView(ew, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(act.label("  ×  ", 16f))
        row.addView(eh, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        AlertDialog.Builder(act, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle(title)
            .setView(row)
            .setPositiveButton("OK") { _, _ ->
                val nw = ew.text.toString().toIntOrNull() ?: 0
                val nh = eh.text.toString().toIntOrNull() ?: 0
                if (nw in 1..Document.MAX_DIM && nh in 1..Document.MAX_DIM) onOk(nw, nh)
                else act.toast("Size must be between 1 and ${Document.MAX_DIM} px")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private val palette = intArrayOf(
        0xFF000000.toInt(), 0xFFFFFFFF.toInt(), 0xFF8E8E93.toInt(), 0xFFFF3B30.toInt(),
        0xFFFF9500.toInt(), 0xFFFFCC00.toInt(), 0xFF34C759.toInt(), 0xFF00C7BE.toInt(),
        0xFF31A8FF.toInt(), 0xFF5856D6.toInt(), 0xFFAF52DE.toInt(), 0xFFFF2D92.toInt(),
        0xFF7B4B2A.toInt(), 0xFFF2C9A0.toInt(), 0xFF1C3A2B.toInt(), 0xFF0A1F44.toInt()
    )

    fun pickColor(act: Activity, initial: Int, onPick: (Int) -> Unit) {
        val hsv = FloatArray(3)
        Color.colorToHSV(initial, hsv)
        val preview = View(act)
        val hex = EditText(act)
        hex.setSingleLine(true)
        hex.setTextColor(UiColors.TEXT)
        hex.filters = arrayOf(android.text.InputFilter.LengthFilter(7))
        var updating = false
        var cur = initial or -0x1000000
        lateinit var hCell: LinearLayout
        lateinit var sCell: LinearLayout
        lateinit var vCell: LinearLayout
        val sbs = ArrayList<SeekBar>()

        fun findSeek(v: LinearLayout): SeekBar = v.getChildAt(1) as SeekBar
        fun push() {
            cur = Color.HSVToColor(hsv)
            preview.background = act.roundBg(cur, 10, UiColors.CARD_HI, 1)
            updating = true
            hex.setText(String.format("#%06X", cur and 0xFFFFFF))
            updating = false
        }
        fun syncSliders() {
            findSeek(hCell).progress = hsv[0].toInt()
            findSeek(sCell).progress = (hsv[1] * 100).toInt()
            findSeek(vCell).progress = (hsv[2] * 100).toInt()
        }
        hCell = act.sliderCell("Hue", 0, 360, hsv[0].toInt()) { hsv[0] = it.toFloat(); push() }
        sCell = act.sliderCell("Saturation", 0, 100, (hsv[1] * 100).toInt()) { hsv[1] = it / 100f; push() }
        vCell = act.sliderCell("Brightness", 0, 100, (hsv[2] * 100).toInt()) { hsv[2] = it / 100f; push() }
        sbs.add(findSeek(hCell))
        hex.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                if (updating) return
                val t = s.toString().trim()
                if (t.length == 7 && t[0] == '#') {
                    try {
                        val c = Color.parseColor(t)
                        Color.colorToHSV(c, hsv)
                        cur = c or -0x1000000
                        preview.background = act.roundBg(cur, 10, UiColors.CARD_HI, 1)
                        syncSliders()
                    } catch (_: IllegalArgumentException) {}
                }
            }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })

        val box = act.vbox()
        box.setPadding(act.dp(20), act.dp(8), act.dp(20), 0)
        val top = act.hbox()
        top.addView(preview, lp(act.dp(56), act.dp(56)))
        top.addView(act.spacer(12, 1))
        top.addView(hex, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        box.addView(top)
        box.addView(hCell); box.addView(sCell); box.addView(vCell)
        // swatches
        val grid = act.vbox()
        var rowBox: LinearLayout? = null
        for ((i, c) in palette.withIndex()) {
            if (i % 8 == 0) { rowBox = act.hbox(); grid.addView(rowBox) }
            val sw = View(act)
            sw.background = act.roundBg(c, 6, UiColors.CARD_HI, 1)
            sw.setOnClickListener {
                Color.colorToHSV(c, hsv)
                syncSliders(); push()
            }
            val p = lp(0, act.dp(34), 1f)
            p.setMargins(act.dp(2), act.dp(3), act.dp(2), act.dp(3))
            rowBox!!.addView(sw, p)
        }
        box.addView(grid)
        push()
        val sv = ScrollView(act)
        sv.addView(box)
        AlertDialog.Builder(act, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Colour")
            .setView(sv)
            .setPositiveButton("OK") { _, _ -> onPick(cur or -0x1000000) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    /**
     * A panel docked to the bottom of the screen that does NOT dim or block the canvas, so the user can see
     * (and pinch-zoom) the live preview while adjusting. Buttons: Cancel / OK.
     */
    fun bottomSheet(
        act: Activity, title: String, content: View, okText: String = "Apply",
        onOk: () -> Unit, onCancel: () -> Unit
    ): Dialog {
        val d = Dialog(act)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val root = act.vbox()
        root.setPadding(act.dp(16), act.dp(10), act.dp(16), act.dp(12))
        root.addView(act.label(title, 15f, UiColors.TEXT, true))
        val sv = ScrollView(act)
        sv.addView(content)
        root.addView(sv, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val btns = act.hbox()
        btns.gravity = Gravity.END
        btns.addView(act.button("Cancel") { d.dismiss(); onCancel() })
        btns.addView(act.spacer(10, 1))
        btns.addView(act.button(okText, true) { d.dismiss(); onOk() })
        val bp = lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        bp.topMargin = act.dp(8)
        root.addView(btns, bp)
        d.setContentView(root)
        d.setCanceledOnTouchOutside(false)
        d.setCancelable(false)
        val w = d.window!!
        w.setBackgroundDrawable(ColorDrawable(UiColors.PANEL))
        w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        w.setGravity(Gravity.BOTTOM)
        w.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        w.addFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL)
        w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        d.show()
        return d
    }
}
