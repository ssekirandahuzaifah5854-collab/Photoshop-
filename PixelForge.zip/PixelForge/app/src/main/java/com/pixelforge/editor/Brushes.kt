package com.pixelforge.editor

import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ComposeShader
import android.graphics.Paint
import android.graphics.PointF
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Soft-edged brush / eraser. The stroke is accumulated in a separate buffer, then merged over the
 * untouched original at the stroke opacity, clipped by the selection. That gives Photoshop-style
 * opacity (no build-up inside a single stroke) and makes erasing and selections work with one code path.
 */
class StrokeEngine(private val doc: Document) {
    private lateinit var before: Bitmap
    private lateinit var live: Bitmap
    private lateinit var buf: Bitmap
    private lateinit var bufCanvas: Canvas
    private lateinit var layerCanvas: Canvas
    private lateinit var dab: Bitmap
    private var erase = false
    private var color = Color.BLACK
    private var size = 40f
    private var hardness = 0.7f
    private var opacity = 1f
    private var pressureOn = true

    private val restorePaint = Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC) }
    private val dabPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val mergePaint = Paint()

    private var started = false
    private var smoothX = 0f
    private var smoothY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var lastP = 1f
    private var carry = 0f
    private val dirty = RectF()
    private var haveDirty = false

    fun begin(isErase: Boolean) {
        val o = ToolOpts
        erase = isErase
        color = if (isErase) Color.BLACK else o.fg
        size = max(1f, o.size)
        hardness = o.hardness
        opacity = o.opacity
        pressureOn = o.pressure
        before = doc.beginEdit()
        live = doc.activeLayer().bitmap
        layerCanvas = Canvas(live)
        buf = Bitmap.createBitmap(live.width, live.height, Bitmap.Config.ARGB_8888)
        bufCanvas = Canvas(buf)
        dab = makeDab(size.roundToInt().coerceAtLeast(1), hardness, color)
        val sel = doc.selection
        mergePaint.alpha = (opacity * 255).roundToInt()
        mergePaint.xfermode = if (erase) PorterDuffXfermode(PorterDuff.Mode.DST_OUT) else null
        if (sel != null) {
            val bs = BitmapShader(buf, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
            val ms = BitmapShader(sel.bitmap(), Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
            mergePaint.shader = ComposeShader(bs, ms, PorterDuff.Mode.DST_IN)
        } else mergePaint.shader = null
        started = false
        carry = 0f
        haveDirty = false
    }

    private fun makeDab(d: Int, hardness: Float, color: Int): Bitmap {
        val b = Bitmap.createBitmap(d, d, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val r = d / 2f
        if (hardness >= 0.98f) {
            p.color = color
            c.drawCircle(r, r, r, p)
        } else {
            val solid = color or -0x1000000
            val clear = color and 0x00FFFFFF
            p.shader = RadialGradient(
                r, r, r, intArrayOf(solid, solid, clear), floatArrayOf(0f, hardness.coerceIn(0f, 0.97f), 1f),
                Shader.TileMode.CLAMP
            )
            c.drawCircle(r, r, r, p)
        }
        return b
    }

    private fun stamp(x: Float, y: Float, pressure: Float) {
        val s = if (pressureOn) size * (0.15f + 0.85f * pressure) else size
        val half = max(0.5f, s / 2f)
        val dst = RectF(x - half, y - half, x + half, y + half)
        bufCanvas.drawBitmap(dab, null, dst, dabPaint)
        if (!haveDirty) { dirty.set(dst); haveDirty = true } else dirty.union(dst)
    }

    fun add(x: Float, y: Float, pressure: Float) {
        val sm = ToolOpts.smoothing
        if (!started) {
            started = true
            smoothX = x; smoothY = y
            lastX = x; lastY = y; lastP = pressure
            stamp(x, y, pressure)
        } else {
            smoothX += (x - smoothX) * (1f - sm)
            smoothY += (y - smoothY) * (1f - sm)
            val dx = smoothX - lastX
            val dy = smoothY - lastY
            val dist = hypot(dx, dy)
            val spacing = max(1f, size * 0.12f)
            if (dist > 0f) {
                var d = spacing - carry
                while (d <= dist) {
                    val t = d / dist
                    stamp(lastX + dx * t, lastY + dy * t, lastP + (pressure - lastP) * t)
                    d += spacing
                }
                carry = dist - (d - spacing)
                lastX = smoothX; lastY = smoothY; lastP = pressure
            }
        }
        refresh()
    }

    private fun refresh() {
        if (!haveDirty) return
        val r = Rect(
            max(0, dirty.left.toInt() - 2), max(0, dirty.top.toInt() - 2),
            min(live.width, ceil(dirty.right).toInt() + 2), min(live.height, ceil(dirty.bottom).toInt() + 2)
        )
        if (r.isEmpty) return
        layerCanvas.save()
        layerCanvas.clipRect(r)
        layerCanvas.drawBitmap(before, 0f, 0f, restorePaint)
        if (mergePaint.shader != null) layerCanvas.drawRect(r, mergePaint)
        else layerCanvas.drawBitmap(buf, 0f, 0f, mergePaint)
        layerCanvas.restore()
        doc.touch()
    }

    fun end() {
        // Finish with the final point so the stroke reaches the finger lift position.
        buf.recycle()
        doc.touch()
    }
}

/** Dab-based retouching tools that read from and write to the live layer. */
class RetouchEngine(private val doc: Document) {
    private lateinit var live: Bitmap
    private var tool = Tool.CLONE
    private var started = false
    private var lastX = 0f
    private var lastY = 0f
    private var carry = 0f
    private var smudgeCarry: IntArray? = null
    private var smudgeD = 0
    private var offX = 0f
    private var offY = 0f
    private var haveOffset = false

    companion object {
        /** Clone source point (in doc coordinates), set by the user. */
        var cloneSource: PointF? = null
        var cloneOffset: PointF? = null
    }

    fun begin(t: Tool, x: Float, y: Float) {
        tool = t
        doc.beginEdit()
        live = doc.activeLayer().bitmap
        started = false
        carry = 0f
        smudgeCarry = null
        haveOffset = false
        if (t == Tool.CLONE || t == Tool.HEAL) {
            val s = cloneSource
            if (s != null) {
                val existing = cloneOffset
                if (existing == null) cloneOffset = PointF(s.x - x, s.y - y)
                offX = cloneOffset!!.x; offY = cloneOffset!!.y
                haveOffset = true
            }
        }
        add(x, y)
    }

    fun hasSource(): Boolean = (tool != Tool.CLONE && tool != Tool.HEAL) || haveOffset

    fun add(x: Float, y: Float) {
        val r = max(1f, ToolOpts.size / 2f)
        val spacing = max(2f, r * if (tool == Tool.SMUDGE) 0.12f else 0.25f)
        if (!started) {
            started = true
            lastX = x; lastY = y
            dab(x, y)
            return
        }
        val dx = x - lastX
        val dy = y - lastY
        val dist = hypot(dx, dy)
        if (dist <= 0f) return
        var d = spacing - carry
        while (d <= dist) {
            val t = d / dist
            dab(lastX + dx * t, lastY + dy * t)
            d += spacing
        }
        carry = dist - (d - spacing)
        lastX = x; lastY = y
    }

    fun end() { doc.touch() }

    // ---------------------------------------------------------------- pixel helpers

    private fun readSquare(b: Bitmap, x0: Int, y0: Int, d: Int, out: IntArray) {
        java.util.Arrays.fill(out, 0)
        val sx = max(0, x0); val sy = max(0, y0)
        val ex = min(b.width, x0 + d); val ey = min(b.height, y0 + d)
        if (ex <= sx || ey <= sy) return
        val w = ex - sx; val h = ey - sy
        val tmp = IntArray(w * h)
        b.getPixels(tmp, 0, w, sx, sy, w, h)
        for (j in 0 until h) System.arraycopy(tmp, j * w, out, (sy - y0 + j) * d + (sx - x0), w)
    }

    private fun writeSquare(b: Bitmap, x0: Int, y0: Int, d: Int, src: IntArray) {
        val sx = max(0, x0); val sy = max(0, y0)
        val ex = min(b.width, x0 + d); val ey = min(b.height, y0 + d)
        if (ex <= sx || ey <= sy) return
        val w = ex - sx; val h = ey - sy
        val tmp = IntArray(w * h)
        for (j in 0 until h) System.arraycopy(src, (sy - y0 + j) * d + (sx - x0), tmp, j * w, w)
        b.setPixels(tmp, 0, w, sx, sy, w, h)
    }

    private fun lerpC(a: Int, b: Int, t: Float): Int {
        if (t <= 0f) return a
        if (t >= 1f) return b
        val ia = (t * 256).toInt()
        val ib = 256 - ia
        val aa = ((a ushr 24) * ib + (b ushr 24) * ia) shr 8
        val rr = ((((a shr 16) and 255) * ib) + (((b shr 16) and 255) * ia)) shr 8
        val gg = ((((a shr 8) and 255) * ib) + (((b shr 8) and 255) * ia)) shr 8
        val bb = (((a and 255) * ib) + ((b and 255) * ia)) shr 8
        return Fx.argb(aa, rr, gg, bb)
    }

    private fun falloff(dist: Float, r: Float): Float {
        val t = dist / r
        if (t >= 1f) return 0f
        val h = ToolOpts.hardness
        if (t <= h) return 1f
        val u = (t - h) / max(0.01f, 1f - h)
        val s = 1f - u
        return s * s * (3f - 2f * s)
    }

    private fun dab(cx: Float, cy: Float) {
        val r = max(1f, ToolOpts.size / 2f)
        val ri = ceil(r).toInt()
        val d = ri * 2 + 1
        val x0 = cx.roundToInt() - ri
        val y0 = cy.roundToInt() - ri
        val fcx = cx - x0
        val fcy = cy - y0
        val cur = IntArray(d * d)
        readSquare(live, x0, y0, d, cur)
        val out = cur.copyOf()
        val sel = doc.selection
        val bw = live.width
        val strength = ToolOpts.strength

        // per-pixel weight = brush falloff * selection coverage
        val wt = FloatArray(d * d)
        for (j in 0 until d) {
            for (i in 0 until d) {
                val gx = x0 + i
                val gy = y0 + j
                if (gx < 0 || gy < 0 || gx >= bw || gy >= live.height) continue
                var w = falloff(hypot(i + 0.5f - fcx, j + 0.5f - fcy), r)
                if (w <= 0f) continue
                if (sel != null) w *= sel.at(gx, gy) / 255f
                wt[j * d + i] = w
            }
        }

        when (tool) {
            Tool.BLUR_BRUSH -> {
                val bl = Fx.blurPx(cur, d, d, max(1, (r / 5f).roundToInt()), 2)
                for (k in out.indices) if (wt[k] > 0f) out[k] = lerpC(cur[k], bl[k], wt[k] * strength)
            }
            Tool.SHARPEN_BRUSH -> {
                val bl = Fx.blurPx(cur, d, d, max(1, (r / 8f).roundToInt()), 2)
                for (k in out.indices) {
                    val w = wt[k] * strength * 2.5f
                    if (wt[k] <= 0f) continue
                    val c = cur[k]; val o = bl[k]
                    out[k] = Fx.argb(
                        c ushr 24,
                        Fx.c8f(((c shr 16) and 255) + (((c shr 16) and 255) - ((o shr 16) and 255)) * w),
                        Fx.c8f(((c shr 8) and 255) + (((c shr 8) and 255) - ((o shr 8) and 255)) * w),
                        Fx.c8f((c and 255) + ((c and 255) - (o and 255)) * w)
                    )
                }
            }
            Tool.DODGE, Tool.BURN -> {
                val dodge = tool == Tool.DODGE
                for (k in out.indices) {
                    val w = wt[k] * strength * 0.35f
                    if (wt[k] <= 0f) continue
                    val c = cur[k]
                    val rr = (c shr 16) and 255; val gg = (c shr 8) and 255; val bb = c and 255
                    out[k] = if (dodge) Fx.argb(c ushr 24, Fx.c8f(rr + (255 - rr) * w), Fx.c8f(gg + (255 - gg) * w), Fx.c8f(bb + (255 - bb) * w))
                    else Fx.argb(c ushr 24, Fx.c8f(rr * (1 - w)), Fx.c8f(gg * (1 - w)), Fx.c8f(bb * (1 - w)))
                }
            }
            Tool.SPONGE -> {
                for (k in out.indices) {
                    val w = wt[k] * strength * 0.4f
                    if (wt[k] <= 0f) continue
                    val c = cur[k]
                    val l = Fx.luma(c)
                    val rr = (c shr 16) and 255; val gg = (c shr 8) and 255; val bb = c and 255
                    // saturate when the user's foreground is "light", desaturate otherwise: use opacity slider direction
                    val sign = if (ToolOpts.opacity >= 0.5f) 1f else -1f
                    out[k] = Fx.argb(c ushr 24,
                        Fx.c8f(rr + (rr - l) * w * sign), Fx.c8f(gg + (gg - l) * w * sign), Fx.c8f(bb + (bb - l) * w * sign))
                }
            }
            Tool.SMUDGE -> {
                val cr = smudgeCarry
                if (cr == null || smudgeD != d) {
                    smudgeCarry = cur.copyOf(); smudgeD = d
                } else {
                    for (k in out.indices) if (wt[k] > 0f) out[k] = lerpC(cur[k], cr[k], wt[k] * (0.35f + 0.6f * strength))
                    smudgeCarry = out.copyOf()
                }
            }
            Tool.CLONE, Tool.HEAL -> {
                if (!haveOffset) return
                val src = IntArray(d * d)
                val sxc = (cx + offX).roundToInt() - ri
                val syc = (cy + offY).roundToInt() - ri
                readSquare(live, sxc, syc, d, src)
                if (tool == Tool.HEAL) {
                    var mr = 0f; var mg = 0f; var mb = 0f
                    var tr = 0f; var tg = 0f; var tb = 0f
                    var n = 0
                    for (k in src.indices) {
                        if (wt[k] <= 0f) continue
                        val s = src[k]; val t = cur[k]
                        mr += (s shr 16) and 255; mg += (s shr 8) and 255; mb += s and 255
                        tr += (t shr 16) and 255; tg += (t shr 8) and 255; tb += t and 255
                        n++
                    }
                    if (n > 0) {
                        val dr = (tr - mr) / n; val dg = (tg - mg) / n; val db = (tb - mb) / n
                        for (k in src.indices) {
                            val s = src[k]
                            src[k] = Fx.argb(s ushr 24, Fx.c8f(((s shr 16) and 255) + dr), Fx.c8f(((s shr 8) and 255) + dg), Fx.c8f((s and 255) + db))
                        }
                    }
                }
                val str = if (tool == Tool.HEAL) 1f else (0.3f + 0.7f * ToolOpts.opacity)
                for (k in out.indices) if (wt[k] > 0f) out[k] = lerpC(cur[k], src[k], wt[k] * str)
            }
            Tool.SPOT -> {
                // Pick the neighbouring patch whose surrounding ring matches best, then heal from it.
                val bestOff = bestSpotOffset(cx, cy, r) ?: return
                val src = IntArray(d * d)
                readSquare(live, (cx + bestOff.x).roundToInt() - ri, (cy + bestOff.y).roundToInt() - ri, d, src)
                var mr = 0f; var mg = 0f; var mb = 0f; var tr = 0f; var tg = 0f; var tb = 0f; var n = 0
                for (k in src.indices) {
                    if (wt[k] <= 0f) continue
                    val s = src[k]; val t = cur[k]
                    mr += (s shr 16) and 255; mg += (s shr 8) and 255; mb += s and 255
                    tr += (t shr 16) and 255; tg += (t shr 8) and 255; tb += t and 255
                    n++
                }
                if (n > 0) {
                    val dr = (tr - mr) / n; val dg = (tg - mg) / n; val db = (tb - mb) / n
                    for (k in src.indices) {
                        val s = src[k]
                        src[k] = Fx.argb(s ushr 24, Fx.c8f(((s shr 16) and 255) + dr), Fx.c8f(((s shr 8) and 255) + dg), Fx.c8f((s and 255) + db))
                    }
                }
                for (k in out.indices) if (wt[k] > 0f) out[k] = lerpC(cur[k], src[k], min(1f, wt[k] * 1.2f))
            }
            Tool.REDEYE -> {
                for (k in out.indices) {
                    if (wt[k] <= 0f) continue
                    val c = cur[k]
                    val rr = (c shr 16) and 255; val gg = (c shr 8) and 255; val bb = c and 255
                    if (rr > 50 && rr > (max(gg, bb) * 1.4f)) {
                        val nr = ((gg + bb) / 2f) * 0.75f
                        out[k] = lerpC(c, Fx.argb(c ushr 24, Fx.c8f(nr), gg, bb), min(1f, wt[k] * 1.5f))
                    }
                }
            }
            else -> return
        }
        writeSquare(live, x0, y0, d, out)
        doc.touch()
    }

    private fun bestSpotOffset(cx: Float, cy: Float, r: Float): PointF? {
        val ring = 16
        val rr = r * 1.25f
        val tp = IntArray(ring)
        for (k in 0 until ring) {
            val a = k * Math.PI * 2 / ring
            tp[k] = sample((cx + Math.cos(a) * rr).toFloat(), (cy + Math.sin(a) * rr).toFloat())
        }
        var best: PointF? = null
        var bestScore = Long.MAX_VALUE
        for (dist in floatArrayOf(2.6f, 3.6f)) {
            for (ang in 0 until 8) {
                val a = ang * Math.PI / 4
                val ox = (Math.cos(a) * r * dist).toFloat()
                val oy = (Math.sin(a) * r * dist).toFloat()
                val scx = cx + ox; val scy = cy + oy
                if (scx - rr < 0 || scy - rr < 0 || scx + rr >= live.width || scy + rr >= live.height) continue
                var score = 0L
                for (k in 0 until ring) {
                    val a2 = k * Math.PI * 2 / ring
                    val c = sample((scx + Math.cos(a2) * rr).toFloat(), (scy + Math.sin(a2) * rr).toFloat())
                    val t = tp[k]
                    val dr = ((c shr 16) and 255) - ((t shr 16) and 255)
                    val dg = ((c shr 8) and 255) - ((t shr 8) and 255)
                    val db = (c and 255) - (t and 255)
                    score += dr * dr + dg * dg + db * db
                }
                if (score < bestScore) { bestScore = score; best = PointF(ox, oy) }
            }
        }
        return best
    }

    private fun sample(x: Float, y: Float): Int {
        val xi = x.roundToInt().coerceIn(0, live.width - 1)
        val yi = y.roundToInt().coerceIn(0, live.height - 1)
        return live.getPixel(xi, yi)
    }
}

/** Fill helpers (paint bucket, gradient, shapes) built on Document.paintOnActive. */
object FillOps {
    fun bucket(doc: Document, x: Int, y: Int) {
        val layer = doc.activeLayer()
        val src = if (ToolOpts.sampleAll) {
            val tmp = Bitmap.createBitmap(doc.width, doc.height, Bitmap.Config.ARGB_8888)
            Compositor.render(doc, tmp)
            val a = IntArray(doc.width * doc.height)
            tmp.getPixels(a, 0, doc.width, 0, 0, doc.width, doc.height)
            tmp.recycle()
            a
        } else {
            val a = IntArray(doc.width * doc.height)
            layer.bitmap.getPixels(a, 0, doc.width, 0, 0, doc.width, doc.height)
            a
        }
        if (x < 0 || y < 0 || x >= doc.width || y >= doc.height) return
        val region = Mask.wand(src, doc.width, doc.height, x, y, ToolOpts.tolerance, ToolOpts.contiguous)
        // grow slightly so anti-aliased edge pixels are covered
        val grown = region.grown(1)
        val color = ToolOpts.fg
        doc.paintOnActive(erase = false, alpha = (ToolOpts.opacity * 255).roundToInt()) { c ->
            val p = Paint()
            p.color = color
            val tmpMask = grown.bitmap()
            // draw colour through the mask bitmap (ALPHA_8 bitmaps are tinted with the paint colour)
            c.drawBitmap(tmpMask, 0f, 0f, p)
        }
    }

    fun gradient(doc: Document, x0: Float, y0: Float, x1: Float, y1: Float) {
        if (abs(x1 - x0) < 1f && abs(y1 - y0) < 1f) return
        val c0 = ToolOpts.fg
        val c1 = if (ToolOpts.gradToTransparent) (ToolOpts.fg and 0x00FFFFFF) else ToolOpts.bg
        doc.paintOnActive(erase = false, alpha = (ToolOpts.opacity * 255).roundToInt()) { c ->
            val p = Paint()
            p.isDither = true
            p.shader = if (ToolOpts.gradRadial) {
                val rad = hypot(x1 - x0, y1 - y0)
                RadialGradient(x0, y0, max(1f, rad), c0, c1, Shader.TileMode.CLAMP)
            } else {
                android.graphics.LinearGradient(x0, y0, x1, y1, c0, c1, Shader.TileMode.CLAMP)
            }
            c.drawRect(0f, 0f, doc.width.toFloat(), doc.height.toFloat(), p)
        }
    }

    fun shape(doc: Document, type: ShapeType, x0: Float, y0: Float, x1: Float, y1: Float) {
        if (abs(x1 - x0) < 1f && abs(y1 - y0) < 1f) return
        val l = min(x0, x1); val t = min(y0, y1); val r = max(x0, x1); val b = max(y0, y1)
        val fill = ToolOpts.shapeFill
        val sw = ToolOpts.shapeStroke
        val color = ToolOpts.fg
        doc.paintOnActive(erase = false, alpha = (ToolOpts.opacity * 255).roundToInt()) { c ->
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            p.color = color
            p.strokeWidth = sw
            p.strokeCap = Paint.Cap.ROUND
            p.strokeJoin = Paint.Join.ROUND
            p.style = if (fill && type != ShapeType.LINE) Paint.Style.FILL else Paint.Style.STROKE
            when (type) {
                ShapeType.LINE -> c.drawLine(x0, y0, x1, y1, p)
                ShapeType.RECT -> c.drawRect(l, t, r, b, p)
                ShapeType.ROUNDRECT -> c.drawRoundRect(RectF(l, t, r, b), min(r - l, b - t) * 0.18f, min(r - l, b - t) * 0.18f, p)
                ShapeType.ELLIPSE -> c.drawOval(RectF(l, t, r, b), p)
            }
        }
    }

    fun fillSelection(doc: Document, color: Int) {
        doc.paintOnActive { c -> c.drawColor(color) }
    }

    @Suppress("unused")
    private fun unused(): Float = sqrt(1f)
}
