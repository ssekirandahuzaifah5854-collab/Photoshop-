package com.pixelforge.editor

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

class MainActivity : Activity(), EditorView.Listener {

    private companion object {
        const val REQ_OPEN_IMAGE = 1
        const val REQ_ADD_IMAGE = 2
        const val REQ_SAVE_PROJECT = 3
        const val REQ_OPEN_PROJECT = 4
        const val REQ_PERM = 5
    }

    private lateinit var ev: EditorView
    private val doc: Document get() = ev.doc

    private lateinit var undoBtn: TextView
    private lateinit var redoBtn: TextView
    private lateinit var zoomLbl: TextView
    private lateinit var optionsBox: LinearLayout
    private lateinit var toolStrip: LinearLayout
    private lateinit var toolScroll: HorizontalScrollView
    private val toolButtons = HashMap<Tool, View>()
    private lateinit var layersPanel: LinearLayout
    private lateinit var layerList: LinearLayout
    private lateinit var layerProps: LinearLayout
    private var layersOpen = false

    private var modal = false
    private var toolBeforeModal: Tool = Tool.BRUSH
    private var progress: Dialog? = null
    private var pendingAfterPermission: (() -> Unit)? = null
    private var lastExport: Uri? = null
    private var lastExportMime = "image/png"

    private val worker = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())

    // ================================================================== lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ev = EditorView(this)
        ev.listener = this
        buildUi()
        ev.setDocument(ImageIO.blankDocument(1080, 1350, Color.WHITE))
        selectTool(Tool.BRUSH)
        afterEdit()
        handleIntent(intent)
        toast("Open a photo from File ▾ — or just start painting")
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    @Suppress("DEPRECATION")
    private fun handleIntent(i: Intent?) {
        i ?: return
        val uri: Uri? = when (i.action) {
            Intent.ACTION_VIEW -> i.data
            Intent.ACTION_SEND -> i.getParcelableExtra(Intent.EXTRA_STREAM)
            else -> null
        }
        if (uri != null) openUri(uri)
        i.action = null
    }

    override fun onDestroy() {
        super.onDestroy()
        worker.shutdown()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        when {
            layersOpen -> toggleLayers()
            doc.dirty -> Dialogs.confirm(this, "Leave PixelForge? Unsaved changes will be lost.\n(Use File → Save project to keep your layers.)", "Leave") { finish() }
            else -> super.onBackPressed()
        }
    }

    // ================================================================== UI construction

    private fun topBtn(text: String, onClick: (View) -> Unit): TextView {
        val t = label(text, 13f, UiColors.TEXT, true)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(13), 0, dp(13), 0)
        t.setOnClickListener { v -> onClick(v) }
        return t
    }

    private fun buildUi() {
        val root = FrameLayout(this)
        root.setBackgroundColor(UiColors.BG)
        val col = vbox()
        root.addView(col, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // ---- top bar
        val topScroll = HorizontalScrollView(this)
        topScroll.isHorizontalScrollBarEnabled = false
        topScroll.setBackgroundColor(UiColors.PANEL)
        val top = hbox()
        topScroll.addView(top, ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val h = lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT)
        top.addView(topBtn("File ▾") { popup(it, fileMenu()) }, h)
        undoBtn = topBtn("↶") { undo() }
        undoBtn.textSize = 20f
        redoBtn = topBtn("↷") { redo() }
        redoBtn.textSize = 20f
        top.addView(undoBtn, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
        top.addView(redoBtn, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
        top.addView(topBtn("Image ▾") { popup(it, imageMenu()) }, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
        top.addView(topBtn("Adjust ▾") { popup(it, Filters.adjustments.map { f -> f.name to { runFilter(f) } }) }, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
        top.addView(topBtn("Filter ▾") { popup(it, Filters.filters.map { f -> f.name to { runFilter(f) } }) }, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
        top.addView(topBtn("Select ▾") { popup(it, selectMenu()) }, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
        top.addView(topBtn("Layers") { toggleLayers() }, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
        zoomLbl = topBtn("100%") { ev.fit() }
        zoomLbl.setTextColor(UiColors.ACCENT)
        top.addView(zoomLbl, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
        col.addView(topScroll, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)))

        // ---- canvas
        col.addView(ev, lp(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        // ---- options
        optionsBox = vbox()
        optionsBox.setBackgroundColor(UiColors.PANEL)
        optionsBox.setPadding(dp(12), dp(8), dp(12), dp(6))
        col.addView(optionsBox, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // ---- tool strip
        toolScroll = HorizontalScrollView(this)
        toolScroll.isHorizontalScrollBarEnabled = false
        toolScroll.setBackgroundColor(UiColors.BG)
        toolStrip = hbox()
        toolScroll.addView(toolStrip)
        var lastGroup = ""
        for (t in Tool.values()) {
            if (t.group != lastGroup) {
                if (lastGroup.isNotEmpty()) {
                    val d = View(this)
                    d.setBackgroundColor(UiColors.CARD_HI)
                    val dp2 = lp(dp(1), dp(34))
                    dp2.setMargins(dp(4), 0, dp(4), 0)
                    toolStrip.addView(d, dp2)
                }
                lastGroup = t.group
            }
            val b = vbox()
            b.gravity = Gravity.CENTER
            b.setPadding(dp(4), dp(6), dp(4), dp(4))
            val ic = label(t.icon, 20f)
            ic.gravity = Gravity.CENTER
            val tx = label(t.label, 10f, UiColors.DIM)
            tx.gravity = Gravity.CENTER
            b.addView(ic)
            b.addView(tx)
            b.setOnClickListener { selectTool(t) }
            toolButtons[t] = b
            toolStrip.addView(b, lp(dp(62), ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        col.addView(toolScroll, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // ---- layers overlay
        layersPanel = vbox()
        layersPanel.background = roundBg(0xF0222229.toInt(), 12, UiColors.CARD_HI, 1)
        layersPanel.setPadding(dp(8), dp(8), dp(8), dp(8))
        layersPanel.elevation = dp(10).toFloat()
        layersPanel.visibility = View.GONE
        val actions = HorizontalScrollView(this)
        actions.isHorizontalScrollBarEnabled = false
        val ar = hbox()
        actions.addView(ar)
        fun act(text: String, f: () -> Unit) {
            val b = button(text) { if (!modal) f() }
            b.setPadding(dp(10), dp(6), dp(10), dp(6))
            val p = lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            p.rightMargin = dp(5)
            ar.addView(b, p)
        }
        act("＋ New") { doc.addLayer("Layer ${doc.layers.size + 1}"); afterEdit() }
        act("Copy") { doc.duplicateActive(); afterEdit() }
        act("Delete") { if (!doc.deleteActive()) toast("A document needs at least one layer"); afterEdit() }
        act("▲") { doc.moveActive(1); afterEdit() }
        act("▼") { doc.moveActive(-1); afterEdit() }
        act("Merge ↓") { if (!doc.mergeDown()) toast("Nothing below to merge with"); afterEdit() }
        act("Flatten") { doc.flatten(); afterEdit() }
        act("＋ Photo") { pickImage(REQ_ADD_IMAGE) }
        act("＋ Text") { editText(null, doc.width / 2f, doc.height / 2f) }
        layersPanel.addView(actions)
        layerProps = vbox()
        layerProps.setPadding(0, dp(6), 0, dp(4))
        layersPanel.addView(layerProps)
        val sv = ScrollView(this)
        layerList = vbox()
        sv.addView(layerList)
        layersPanel.addView(sv, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(200)))
        val lpP = FrameLayout.LayoutParams(dp(300), ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.END or Gravity.TOP)
        lpP.topMargin = dp(50)
        lpP.rightMargin = dp(6)
        root.addView(layersPanel, lpP)

        setContentView(root)
    }

    private fun popup(anchor: View, items: List<Pair<String, () -> Unit>>) {
        if (modal) return
        val pm = PopupMenu(this, anchor)
        for ((i, it) in items.withIndex()) pm.menu.add(0, i, i, it.first)
        pm.setOnMenuItemClickListener { mi -> items[mi.itemId].second(); true }
        pm.show()
    }

    // ================================================================== menus

    private fun fileMenu(): List<Pair<String, () -> Unit>> = listOf(
        "New…" to { newDocument() },
        "Open photo…" to { confirmDiscard { pickImage(REQ_OPEN_IMAGE) } },
        "Open project…" to { confirmDiscard { pickProject() } },
        "Add photo as layer…" to { pickImage(REQ_ADD_IMAGE) },
        "Save project (keeps layers)…" to { saveProject() },
        "Export image (PNG / JPEG / WebP)…" to { exportDialog() },
        "Share last export" to { shareLast() }
    )

    private fun imageMenu(): List<Pair<String, () -> Unit>> = listOf(
        "Crop" to { selectTool(Tool.CROP) },
        "Rotate 90° right" to { safe { doc.rotate(90); canvasChanged() } },
        "Rotate 90° left" to { safe { doc.rotate(270); canvasChanged() } },
        "Rotate 180°" to { safe { doc.rotate(180); canvasChanged() } },
        "Flip horizontal" to { safe { doc.flip(true); afterEdit() } },
        "Flip vertical" to { safe { doc.flip(false); afterEdit() } },
        "Resize image…" to {
            Dialogs.askSize(this, "Resize image", doc.width, doc.height, true) { w, h -> safe { doc.resizeImage(w, h); canvasChanged() } }
        },
        "Canvas size…" to {
            Dialogs.askSize(this, "Canvas size", doc.width, doc.height, false) { w, h -> safe { doc.resizeCanvas(w, h); canvasChanged() } }
        },
        "Flip layer horizontally" to { flipLayer(true) },
        "Flip layer vertically" to { flipLayer(false) },
        "Rotate layer 90°" to { rotateLayer() },
        "Flatten image" to { doc.flatten(); afterEdit() },
        "Fit to screen" to { ev.fit() },
        "Zoom to 100%" to { ev.zoomActual() }
    )

    private fun selectMenu(): List<Pair<String, () -> Unit>> = listOf(
        "Select all" to { doc.commitSelection(Mask.full(doc.width, doc.height)); afterEdit() },
        "Deselect" to { if (doc.selection != null) { doc.commitSelection(null); afterEdit() } },
        "Invert selection" to { withSelection { doc.commitSelection(it.inverted()); afterEdit() } },
        "Feather…" to { withSelection { s -> Dialogs.askNumber(this, "Feather", 1, 100, 10, " px") { r -> changeSelection { s.feathered(r) } } } },
        "Grow…" to { withSelection { s -> Dialogs.askNumber(this, "Grow", 1, 60, 5, " px") { r -> changeSelection { s.grown(r) } } } },
        "Shrink…" to { withSelection { s -> Dialogs.askNumber(this, "Shrink", 1, 60, 5, " px") { r -> changeSelection { s.shrunk(r) } } } },
        "Auto-select subject (plain background)…" to { autoSubject(false) },
        "Remove plain background…" to { autoSubject(true) },
        "Fill selection with foreground" to { if (!layerHidden()) { FillOps.fillSelection(doc, ToolOpts.fg); afterEdit() } },
        "Delete selection contents" to { withSelection { s -> if (!layerHidden()) { cutOut(s, false); afterEdit() } } },
        "Copy selection to new layer" to { withSelection { s -> copyToLayer(s, false) } },
        "Cut selection to new layer" to { withSelection { s -> copyToLayer(s, true) } }
    )

    // ================================================================== tools & options panel

    private fun selectTool(t: Tool) {
        if (modal) return
        ev.tool = t
        for ((k, v) in toolButtons) v.background = if (k == t) roundBg(UiColors.CARD_HI, 10, UiColors.ACCENT, 1) else null
        buildOptions()
        toolButtons[t]?.let { b -> toolScroll.post { toolScroll.smoothScrollTo(b.left - toolScroll.width / 2 + b.width / 2, 0) } }
    }

    private lateinit var fgSwatch: View
    private lateinit var bgSwatch: View

    private fun refreshSwatches() {
        fgSwatch.background = roundBg(ToolOpts.fg, 8, Color.WHITE, 2)
        bgSwatch.background = roundBg(ToolOpts.bg, 8, UiColors.DIM, 1)
    }

    private fun hint(s: String): TextView {
        val t = label(s, 12f, UiColors.DIM)
        t.setPadding(0, dp(2), 0, dp(2))
        return t
    }

    private fun buildOptions() {
        val t = ev.tool
        optionsBox.removeAllViews()
        val head = hbox()
        fgSwatch = View(this); bgSwatch = View(this)
        fgSwatch.setOnClickListener { Dialogs.pickColor(this, ToolOpts.fg) { c -> ToolOpts.fg = c; refreshSwatches() } }
        bgSwatch.setOnClickListener { Dialogs.pickColor(this, ToolOpts.bg) { c -> ToolOpts.bg = c; refreshSwatches() } }
        head.addView(fgSwatch, lp(dp(34), dp(34)))
        head.addView(spacer(6, 1))
        head.addView(bgSwatch, lp(dp(34), dp(34)))
        head.addView(spacer(6, 1))
        val swap = button("⇄") { val a = ToolOpts.fg; ToolOpts.fg = ToolOpts.bg; ToolOpts.bg = a; refreshSwatches() }
        swap.setPadding(dp(10), dp(5), dp(10), dp(5))
        head.addView(swap)
        head.addView(spacer(10, 1))
        val title = label("${t.icon}  ${t.label}", 14f, UiColors.TEXT, true)
        head.addView(title, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        optionsBox.addView(head)
        refreshSwatches()
        val gap = { optionsBox.addView(spacer(1, 6)) }

        fun sl(name: String, min: Int, max: Int, v: Int, fmt: (Int) -> String = { it.toString() }, set: (Int) -> Unit) =
            sliderCell(name, min, max, v, fmt, null, null, set)

        val sizeCell = { sl("Size", 1, 300, ToolOpts.size.toInt(), { "$it px" }) { ToolOpts.size = it.toFloat() } }
        val hardCell = { sl("Hardness", 0, 100, (ToolOpts.hardness * 100).toInt(), { "$it%" }) { ToolOpts.hardness = it / 100f } }
        val opacCell = { sl("Opacity", 1, 100, (ToolOpts.opacity * 100).toInt(), { "$it%" }) { ToolOpts.opacity = it / 100f } }
        val strCell = { sl("Strength", 1, 100, (ToolOpts.strength * 100).toInt(), { "$it%" }) { ToolOpts.strength = it / 100f } }
        val tolCell = { sl("Tolerance", 0, 255, ToolOpts.tolerance) { ToolOpts.tolerance = it } }
        val selChips = {
            chips(listOf("New", "Add", "Subtract", "Intersect"), ToolOpts.selMode.ordinal) { ToolOpts.selMode = SelMode.values()[it] }
        }

        when (t) {
            Tool.BRUSH, Tool.ERASER -> {
                gap()
                optionsBox.addView(cells(sizeCell(), hardCell()))
                optionsBox.addView(cells(opacCell(), sl("Smoothing", 0, 90, (ToolOpts.smoothing * 100).toInt(), { "$it%" }) { ToolOpts.smoothing = it / 100f }))
                optionsBox.addView(toggleChip("Pen pressure", ToolOpts.pressure) { ToolOpts.pressure = it })
            }
            Tool.CLONE, Tool.HEAL -> {
                gap()
                optionsBox.addView(cells(sizeCell(), hardCell()))
                if (t == Tool.CLONE) optionsBox.addView(opacCell())
                val b = button("Set source point") { ev.settingCloneSource = true; toast("Now tap the spot to copy from") }
                optionsBox.addView(b)
                optionsBox.addView(hint("1) Tap “Set source point”, tap the good area.  2) Paint over the blemish."))
            }
            Tool.SPOT, Tool.REDEYE -> {
                gap()
                optionsBox.addView(sizeCell())
                optionsBox.addView(hint(if (t == Tool.SPOT) "Tap or brush over a blemish — it's replaced with nearby texture." else "Tap on the red pupil."))
            }
            Tool.SMUDGE, Tool.BLUR_BRUSH, Tool.SHARPEN_BRUSH, Tool.DODGE, Tool.BURN -> {
                gap()
                optionsBox.addView(cells(sizeCell(), hardCell()))
                optionsBox.addView(strCell())
            }
            Tool.SPONGE -> {
                gap()
                optionsBox.addView(cells(sizeCell(), hardCell()))
                optionsBox.addView(strCell())
                optionsBox.addView(chips(listOf("Saturate", "Desaturate"), if (ToolOpts.opacity >= 0.5f) 0 else 1) { ToolOpts.opacity = if (it == 0) 1f else 0.25f })
            }
            Tool.BUCKET -> {
                gap()
                optionsBox.addView(cells(tolCell(), opacCell()))
                val r = hbox()
                r.addView(toggleChip("Contiguous", ToolOpts.contiguous) { ToolOpts.contiguous = it })
                r.addView(spacer(6, 1))
                r.addView(toggleChip("Sample all layers", ToolOpts.sampleAll) { ToolOpts.sampleAll = it })
                optionsBox.addView(r)
            }
            Tool.WAND -> {
                gap()
                optionsBox.addView(tolCell())
                val r = hbox()
                r.addView(toggleChip("Contiguous", ToolOpts.contiguous) { ToolOpts.contiguous = it })
                r.addView(spacer(6, 1))
                r.addView(toggleChip("Sample all layers", ToolOpts.sampleAll) { ToolOpts.sampleAll = it })
                optionsBox.addView(r)
                gap()
                optionsBox.addView(selChips())
            }
            Tool.MARQUEE_RECT, Tool.MARQUEE_ELLIPSE, Tool.LASSO -> {
                gap()
                optionsBox.addView(selChips())
                optionsBox.addView(hint("Drag on the image. Tap once to clear the selection."))
            }
            Tool.SELECT_BRUSH -> {
                gap()
                optionsBox.addView(sizeCell())
                optionsBox.addView(selChips())
                optionsBox.addView(hint("Paint over what you want to select."))
            }
            Tool.GRADIENT -> {
                gap()
                optionsBox.addView(opacCell())
                optionsBox.addView(chips(listOf("Linear", "Radial"), if (ToolOpts.gradRadial) 1 else 0) { ToolOpts.gradRadial = it == 1 })
                optionsBox.addView(spacer(1, 4))
                optionsBox.addView(chips(listOf("Foreground → Background", "Foreground → Transparent"), if (ToolOpts.gradToTransparent) 1 else 0) { ToolOpts.gradToTransparent = it == 1 })
            }
            Tool.SHAPE -> {
                gap()
                optionsBox.addView(chips(listOf("Line", "Rectangle", "Rounded", "Ellipse"), ToolOpts.shape.ordinal) { ToolOpts.shape = ShapeType.values()[it] })
                optionsBox.addView(spacer(1, 4))
                optionsBox.addView(cells(opacCell(), sl("Line width", 1, 80, ToolOpts.shapeStroke.toInt(), { "$it px" }) { ToolOpts.shapeStroke = it.toFloat() }))
                optionsBox.addView(toggleChip("Filled", ToolOpts.shapeFill) { ToolOpts.shapeFill = it })
            }
            Tool.TEXT -> {
                gap()
                optionsBox.addView(hint("Tap the image to add text. Text stays editable until you paint on that layer."))
                optionsBox.addView(button("Edit text of the selected layer") {
                    val l = doc.activeLayer()
                    if (l.text != null) editText(l, 0f, 0f) else toast("Select a text layer first")
                })
            }
            Tool.CROP -> {
                gap()
                val ratios = listOf<Float?>(null, 1f, 4f / 5f, 3f / 2f, 16f / 9f, 9f / 16f)
                optionsBox.addView(chips(listOf("Free", "1:1", "4:5", "3:2", "16:9", "9:16"), 0) { ev.setCropAspect(ratios[it]) })
                optionsBox.addView(spacer(1, 6))
                val r = hbox()
                r.addView(button("Cancel") { ev.cancelCrop(); ev.beginCrop() }, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                r.addView(spacer(8, 1))
                r.addView(button("Apply crop", true) { ev.applyCrop(); ev.beginCrop() }, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                optionsBox.addView(r)
            }
            Tool.MOVE -> {
                gap()
                optionsBox.addView(hint("Drag to move the selected layer. Pinch to zoom the view."))
            }
            Tool.TRANSFORM -> {
                gap()
                optionsBox.addView(hint("Drag with one finger to move; use two fingers to scale and rotate the selected layer."))
            }
            Tool.HAND -> optionsBox.addView(hint("Drag to pan. Pinch to zoom. Tap the % in the top bar to fit the screen."))
            Tool.EYEDROPPER -> optionsBox.addView(hint("Touch the image to pick the foreground colour."))
        }
    }

    // ================================================================== state refresh

    private fun refreshUndoButtons() {
        undoBtn.alpha = if (doc.canUndo()) 1f else 0.35f
        redoBtn.alpha = if (doc.canRedo()) 1f else 0.35f
    }

    private fun afterEdit() {
        refreshUndoButtons()
        if (layersOpen) rebuildLayers()
        ev.invalidate()
    }

    private fun canvasChanged() {
        ev.fit()
        afterEdit()
    }

    override fun onChanged(structural: Boolean) { afterEdit() }
    override fun onColorPicked(c: Int) { ToolOpts.fg = c; refreshSwatches() }
    override fun onTextTap(x: Float, y: Float) { editText(null, x, y) }
    override fun onCropState(active: Boolean) {}
    override fun onMessage(s: String) { toast(s) }
    override fun onZoom(pct: Int) { zoomLbl.text = "$pct%" }

    private fun undo() {
        if (modal) return
        val ow = doc.width; val oh = doc.height
        if (doc.undo()) {
            if (doc.width != ow || doc.height != oh) ev.fit()
            ev.redrawComp(); afterEdit()
        } else toast("Nothing to undo")
    }

    private fun redo() {
        if (modal) return
        val ow = doc.width; val oh = doc.height
        if (doc.redo()) {
            if (doc.width != ow || doc.height != oh) ev.fit()
            ev.redrawComp(); afterEdit()
        } else toast("Nothing to redo")
    }

    private fun errMsg(t: Throwable): String =
        if (t is OutOfMemoryError) "Not enough memory — try a smaller image" else (t.message ?: t.toString())

    private fun safe(f: () -> Unit) {
        try { f() } catch (t: Throwable) { toast(errMsg(t)) }
    }

    private fun layerHidden(): Boolean {
        if (!doc.activeLayer().visible) { toast("This layer is hidden — show it first"); return true }
        return false
    }

    // ================================================================== modal / progress helpers

    private fun enterModal() {
        modal = true
        toolBeforeModal = ev.tool
        ev.tool = Tool.HAND
        toolScroll.alpha = 0.35f
    }

    private fun exitModal() {
        modal = false
        ev.tool = toolBeforeModal
        toolScroll.alpha = 1f
        ev.redrawComp()
        afterEdit()
    }

    private fun showProgress(msg: String) {
        hideProgress()
        val box = hbox()
        box.setPadding(dp(24), dp(20), dp(24), dp(20))
        box.addView(android.widget.ProgressBar(this), lp(dp(36), dp(36)))
        box.addView(spacer(16, 1))
        box.addView(label(msg, 15f))
        val d = AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert).setView(box).setCancelable(false).create()
        d.show()
        progress = d
    }

    private fun hideProgress() {
        progress?.dismiss()
        progress = null
    }

    /** Runs [work] on a background thread behind a progress dialog, then [done] on the UI thread. */
    private fun busy(msg: String, work: () -> Unit, done: () -> Unit) {
        showProgress(msg)
        worker.execute {
            var err: Throwable? = null
            try { work() } catch (t: Throwable) { err = t }
            runOnUiThread {
                hideProgress()
                if (err != null) toast(errMsg(err)) else safe(done)
            }
        }
    }

    // ================================================================== documents / files

    private fun confirmDiscard(then: () -> Unit) {
        if (doc.dirty) Dialogs.confirm(this, "Discard the current document? Unsaved changes will be lost.", "Discard") { then() } else then()
    }

    private fun setDocument(d: Document) {
        ev.setDocument(d)
        ev.tool = ev.tool
        afterEdit()
        if (layersOpen) rebuildLayers()
    }

    private fun newDocument() {
        confirmDiscard {
            val presets = listOf(
                "Square  1080 × 1080", "Portrait  1080 × 1350", "Story  1080 × 1920",
                "Landscape  1920 × 1080", "HD wallpaper  2160 × 2560", "Custom size…"
            )
            Dialogs.choose(this, "New document", presets) { i ->
                val sizes = listOf(1080 to 1080, 1080 to 1350, 1080 to 1920, 1920 to 1080, 2160 to 2560)
                val create = { w: Int, h: Int ->
                    Dialogs.choose(this, "Background", listOf("White", "Black", "Transparent")) { b ->
                        val fill = when (b) { 0 -> Color.WHITE; 1 -> Color.BLACK; else -> 0 }
                        safe { setDocument(ImageIO.blankDocument(w, h, fill)) }
                    }
                }
                if (i < sizes.size) create(sizes[i].first, sizes[i].second)
                else Dialogs.askSize(this, "Custom size", 1080, 1080, false) { w, h -> create(w, h) }
            }
        }
    }

    private fun pickImage(req: Int) {
        val i = Intent(Intent.ACTION_GET_CONTENT)
        i.type = "image/*"
        i.addCategory(Intent.CATEGORY_OPENABLE)
        try { startActivityForResult(Intent.createChooser(i, "Choose a photo"), req) } catch (e: Exception) { toast("No gallery app found") }
    }

    private fun pickProject() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.type = "*/*"
        i.addCategory(Intent.CATEGORY_OPENABLE)
        try { startActivityForResult(i, REQ_OPEN_PROJECT) } catch (e: Exception) { toast("No file picker found") }
    }

    private fun saveProject() {
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
        i.type = "application/octet-stream"
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.putExtra(Intent.EXTRA_TITLE, "project.pforge")
        try { startActivityForResult(i, REQ_SAVE_PROJECT) } catch (e: Exception) { toast("No file picker found") }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        when (requestCode) {
            REQ_OPEN_IMAGE, REQ_OPEN_PROJECT -> openUri(uri)
            REQ_ADD_IMAGE -> addPhotoLayer(uri)
            REQ_SAVE_PROJECT -> {
                val d = doc
                busy("Saving project…", { ImageIO.saveProject(this, d, uri) }) { toast("Project saved"); afterEdit() }
            }
        }
    }

    private fun openUri(uri: Uri) {
        confirmDiscard {
            var nd: Document? = null
            busy("Opening…", {
                nd = if (ImageIO.looksLikeProject(this, uri)) ImageIO.loadProject(this, uri)
                else ImageIO.documentFromBitmap(ImageIO.decode(this, uri))
            }) { nd?.let { setDocument(it) } }
        }
    }

    private fun addPhotoLayer(uri: Uri) {
        var bmp: Bitmap? = null
        busy("Adding photo…", { bmp = ImageIO.decode(this, uri) }) {
            val src = bmp ?: return@busy
            val placed = ImageIO.placeOnLayer(doc, src)
            src.recycle()
            doc.addBitmapLayer("Photo", placed)
            afterEdit()
            selectTool(Tool.MOVE)
            toast("Photo added — drag to move, or use Transform to scale/rotate")
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_PERM) {
            val p = pendingAfterPermission
            pendingAfterPermission = null
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) p?.invoke()
            else toast("Storage permission is needed to save images")
        }
    }

    private fun exportDialog() {
        var fmt = ImageIO.Format.PNG
        var quality = 92
        val box = vbox()
        box.setPadding(dp(20), dp(10), dp(20), 0)
        box.addView(chips(listOf("PNG", "JPEG", "WebP"), 0) { fmt = ImageIO.Format.values()[it] })
        box.addView(spacer(1, 8))
        box.addView(sliderCell("Quality (JPEG / WebP)", 40, 100, quality, { "$it%" }) { quality = it })
        box.addView(hint("Saved to Pictures/PixelForge  ·  ${doc.width} × ${doc.height} px"))
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Export image")
            .setView(box)
            .setPositiveButton("Save") { _, _ -> doExport(fmt, quality) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun doExport(fmt: ImageIO.Format, quality: Int) {
        if (Build.VERSION.SDK_INT < 29 && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            pendingAfterPermission = { doExport(fmt, quality) }
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), REQ_PERM)
            return
        }
        val name = "PixelForge_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val d = doc
        var out: Uri? = null
        busy("Exporting…", { out = ImageIO.export(this, d, fmt, quality, name) }) {
            lastExport = out
            lastExportMime = fmt.mime
            Dialogs.confirm(this, "Saved to Pictures/PixelForge as $name.${fmt.ext}", "Share") { shareLast() }
        }
    }

    private fun shareLast() {
        val u = lastExport
        if (u == null) { toast("Export an image first"); return }
        val i = Intent(Intent.ACTION_SEND)
        i.type = lastExportMime
        i.putExtra(Intent.EXTRA_STREAM, u)
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(i, "Share image"))
    }

    // ================================================================== selections / cutout

    private fun withSelection(f: (Mask) -> Unit) {
        val s = doc.selection
        if (s == null) toast("Make a selection first (Select tools)") else f(s)
    }

    private fun changeSelection(make: () -> Mask) {
        var m: Mask? = null
        busy("Working…", { m = make() }) {
            val r = m
            doc.commitSelection(if (r == null || r.isEmpty()) null else r)
            afterEdit()
        }
    }

    /** Erase inside (keepInside=false) or outside (keepInside=true) the mask on the active layer. */
    private fun cutOut(mask: Mask, keepInside: Boolean) {
        doc.beginEdit()
        val p = Paint()
        p.xfermode = PorterDuffXfermode(if (keepInside) PorterDuff.Mode.DST_IN else PorterDuff.Mode.DST_OUT)
        Canvas(doc.activeLayer().bitmap).drawBitmap(mask.bitmap(), 0f, 0f, p)
        doc.touch()
    }

    private fun copyToLayer(mask: Mask, cut: Boolean) {
        if (layerHidden()) return
        safe {
            val src = doc.activeLayer().bitmap
            val bmp = src.copy(Bitmap.Config.ARGB_8888, true) ?: throw OutOfMemoryError()
            val p = Paint()
            p.xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
            Canvas(bmp).drawBitmap(mask.bitmap(), 0f, 0f, p)
            if (cut) cutOut(mask, false)
            doc.addBitmapLayer(if (cut) "Cut-out" else "Selection", bmp)
            afterEdit()
            toast(if (cut) "Cut to a new layer" else "Copied to a new layer")
        }
    }

    private fun autoSubject(removeBackground: Boolean) {
        if (layerHidden()) return
        Dialogs.askNumber(this, "Background tolerance", 5, 120, 40) { tol ->
            val w = doc.width; val h = doc.height
            val px = IntArray(w * h)
            doc.activeLayer().bitmap.getPixels(px, 0, w, 0, 0, w, h)
            var m: Mask? = null
            busy("Finding the subject…", { m = Mask.autoSubject(px, w, h, tol) }) {
                val r = m
                if (r == null || r.isEmpty()) { toast("Nothing found — try a higher tolerance"); return@busy }
                if (removeBackground) {
                    cutOut(r, true)
                    doc.selection = null
                    toast("Background removed")
                } else {
                    doc.commitSelection(r)
                    toast("Subject selected — refine with the select tools, then copy it to a layer")
                }
                afterEdit()
            }
        }
    }

    // ================================================================== layer transforms

    private fun flipLayer(horizontal: Boolean) {
        val m = Matrix()
        if (horizontal) { m.setScale(-1f, 1f); m.postTranslate(doc.width.toFloat(), 0f) }
        else { m.setScale(1f, -1f); m.postTranslate(0f, doc.height.toFloat()) }
        safe { doc.transformActiveLayer(m); afterEdit() }
    }

    private fun rotateLayer() {
        val m = Matrix()
        m.setRotate(90f, doc.width / 2f, doc.height / 2f)
        safe { doc.transformActiveLayer(m); afterEdit() }
    }

    // ================================================================== layers panel

    private fun toggleLayers() {
        layersOpen = !layersOpen
        layersPanel.visibility = if (layersOpen) View.VISIBLE else View.GONE
        if (layersOpen) rebuildLayers()
    }

    private fun rebuildLayers() {
        layerList.removeAllViews()
        val tw = dp(44)
        for (i in doc.layers.indices.reversed()) {
            val l = doc.layers[i]
            val row = hbox()
            row.setPadding(dp(6), dp(5), dp(6), dp(5))
            row.background = roundBg(if (i == doc.active) 0xFF244A66.toInt() else UiColors.CARD, 8)
            val eye = label(if (l.visible) "👁" else "—", 18f, if (l.visible) UiColors.TEXT else UiColors.DIM)
            eye.gravity = Gravity.CENTER
            eye.setOnClickListener {
                doc.pushUndo(); l.visible = !l.visible; doc.touch(); afterEdit()
            }
            row.addView(eye, lp(dp(34), dp(34)))
            val th = ImageView(this)
            th.setBackgroundColor(0xFF666672.toInt())
            th.scaleType = ImageView.ScaleType.FIT_CENTER
            try {
                val sc = tw.toFloat() / maxOf(l.bitmap.width, l.bitmap.height)
                th.setImageBitmap(Bitmap.createScaledBitmap(l.bitmap, maxOf(1, (l.bitmap.width * sc).toInt()), maxOf(1, (l.bitmap.height * sc).toInt()), true))
            } catch (_: Throwable) {}
            val tp = lp(tw, tw)
            tp.leftMargin = dp(4); tp.rightMargin = dp(8)
            row.addView(th, tp)
            val nm = label(l.name + if (l.text != null) "  ᴛ" else "", 13f, UiColors.TEXT, i == doc.active)
            nm.maxLines = 1
            nm.ellipsize = android.text.TextUtils.TruncateAt.END
            row.addView(nm, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.setOnClickListener { if (!modal) { doc.active = i; rebuildLayers() } }
            row.setOnLongClickListener {
                if (!modal) Dialogs.inputText(this, "Rename layer", l.name) { s ->
                    if (s.isNotBlank()) { doc.active = i; doc.changeProps { it.name = s.trim() }; afterEdit() }
                }
                true
            }
            val p = lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            p.bottomMargin = dp(4)
            layerList.addView(row, p)
        }
        // properties of the active layer
        layerProps.removeAllViews()
        val l = doc.activeLayer()
        layerProps.addView(sliderCell("Opacity", 0, 100, l.opacity, { "$it%" },
            onStart = { doc.pushUndo() },
            onStop = { refreshUndoButtons() }
        ) { v -> doc.activeLayer().opacity = v; doc.touch(); ev.invalidate() })
        val bb = button("Blend: ${l.blend.label}  ▾") {
            if (modal) return@button
            val all = Blend.available()
            Dialogs.choose(this, "Blend mode", all.map { it.label }) { i -> doc.changeProps { it.blend = all[i] }; afterEdit() }
        }
        bb.setPadding(dp(10), dp(6), dp(10), dp(6))
        val bp = lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        bp.topMargin = dp(4)
        layerProps.addView(bb, bp)
    }

    // ================================================================== filters / adjustments

    private fun runFilter(def: FilterDef) {
        if (modal || layerHidden()) return
        val w = doc.width; val h = doc.height
        val orig = IntArray(w * h)
        doc.activeLayer().bitmap.getPixels(orig, 0, w, 0, 0, w, h)
        val selBytes = doc.selection?.a

        fun compute(vals: IntArray): IntArray = Fx.maskBlend(orig, def.fn(orig.copyOf(), w, h, vals), selBytes)

        if (def.params.isEmpty()) {
            var res: IntArray? = null
            busy("Applying ${def.name}…", { res = compute(IntArray(0)) }) {
                val r = res ?: return@busy
                doc.beginEdit()
                doc.activeLayer().bitmap.setPixels(r, 0, w, 0, 0, w, h)
                doc.touch()
                afterEdit()
            }
            return
        }

        enterModal()
        doc.beginEdit()
        val target = doc.activeLayer().bitmap
        val vals = IntArray(def.params.size) { def.params[it].def }
        val gen = AtomicInteger(0)

        fun schedule() {
            val g = gen.incrementAndGet()
            val q = vals.copyOf()
            worker.execute {
                if (g != gen.get()) return@execute
                try {
                    val r = Fx.maskBlend(orig, def.fn(orig.copyOf(), w, h, q), selBytes)
                    runOnUiThread {
                        if (g == gen.get()) {
                            target.setPixels(r, 0, w, 0, 0, w, h)
                            doc.touch()
                            ev.invalidate()
                        }
                    }
                } catch (t: Throwable) {
                    runOnUiThread { toast(errMsg(t)) }
                }
            }
        }

        val content = vbox()
        for ((i, p) in def.params.withIndex()) {
            if (p.toggle) {
                content.addView(toggleChip(p.name, p.def == 1) { vals[i] = if (it) 1 else 0; schedule() })
                content.addView(spacer(1, 6))
            } else {
                content.addView(sliderCell(p.name, p.min, p.max, p.def, { it.toString() },
                    onStart = null,
                    onStop = { if (def.heavy) schedule() }
                ) { v -> vals[i] = v; if (!def.heavy) schedule() })
            }
        }
        if (def.heavy) content.addView(hint("This filter is slow on big images — the preview updates when you lift your finger."))

        Dialogs.bottomSheet(this, def.name, content, "Apply",
            onOk = {
                val g = gen.incrementAndGet()
                showProgress("Applying ${def.name}…")
                val q = vals.copyOf()
                worker.execute {
                    var r: IntArray? = null
                    var err: Throwable? = null
                    try { r = Fx.maskBlend(orig, def.fn(orig.copyOf(), w, h, q), selBytes) } catch (t: Throwable) { err = t }
                    runOnUiThread {
                        hideProgress()
                        if (r != null && g == gen.get()) {
                            target.setPixels(r, 0, w, 0, 0, w, h)
                            doc.touch()
                        } else {
                            doc.cancelEdit()
                            if (err != null) toast(errMsg(err))
                        }
                        exitModal()
                    }
                }
            },
            onCancel = {
                gen.incrementAndGet()
                doc.cancelEdit()
                exitModal()
            })
        schedule()
    }

    // ================================================================== text layers

    private fun editText(existing: Layer?, tapX: Float, tapY: Float) {
        if (modal) return
        val layer: Layer
        val td: TextData
        val isNew: Boolean
        if (existing?.text != null) {
            doc.pushUndo()
            layer = existing
            td = existing.text!!
            isNew = false
        } else {
            val size = doc.width * 0.09f
            layer = doc.addLayer("Text")
            td = TextData(text = "Your text", size = size, color = ToolOpts.fg, x = tapX, y = tapY - size * 0.6f,
                strokeColor = if (Color.luminance(ToolOpts.fg) > 0.5f) Color.BLACK else Color.WHITE)
            layer.text = td
            isNew = true
        }
        enterModal()
        val pending = Runnable {
            layer.bitmap = TextRender.render(td, doc.width, doc.height)
            doc.touch()
            ev.invalidate()
        }
        fun render() { ui.removeCallbacks(pending); ui.postDelayed(pending, 40) }
        pending.run()

        val content = vbox()
        val et = android.widget.EditText(this)
        et.setText(td.text)
        et.minLines = 2
        et.gravity = Gravity.TOP or Gravity.START
        et.setTextColor(UiColors.TEXT)
        et.addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(s: android.text.Editable?) { td.text = s.toString(); render() }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        content.addView(et)
        content.addView(cells(
            sliderCell("Size", 8, 800, td.size.toInt(), { "$it px" }) { td.size = it.toFloat(); render() },
            sliderCell("Letter spacing", -10, 60, td.spacing.toInt()) { td.spacing = it.toFloat(); render() }
        ))
        content.addView(cells(
            sliderCell("Outline", 0, 40, td.strokeW.toInt(), { "$it px" }) { td.strokeW = it.toFloat(); render() },
            hbox().also { r ->
                r.addView(button("Text colour") { Dialogs.pickColor(this, td.color) { c -> td.color = c; render() } })
                r.addView(spacer(6, 1))
                r.addView(button("Outline colour") { Dialogs.pickColor(this, td.strokeColor) { c -> td.strokeColor = c; render() } })
            }
        ))
        val toggles = hbox()
        toggles.addView(toggleChip("Bold", td.bold) { td.bold = it; render() })
        toggles.addView(spacer(6, 1))
        toggles.addView(toggleChip("Italic", td.italic) { td.italic = it; render() })
        toggles.addView(spacer(6, 1))
        toggles.addView(toggleChip("Shadow", td.shadow) { td.shadow = it; render() })
        content.addView(spacer(1, 6))
        content.addView(toggles)
        content.addView(spacer(1, 6))
        content.addView(chips(TextRender.families, td.family) { td.family = it; render() })
        content.addView(spacer(1, 6))
        content.addView(chips(listOf("Left", "Centre", "Right"), td.align) { td.align = it; render() })

        Dialogs.bottomSheet(this, if (isNew) "Add text" else "Edit text", content, "Done",
            onOk = {
                ui.removeCallbacks(pending); pending.run()
                if (td.text.isBlank()) {
                    if (isNew) doc.cancelEdit() else { doc.cancelEdit(); toast("Text can't be empty") }
                } else if (layer.name == "Text") {
                    layer.name = td.text.lines().first().trim().take(20).ifEmpty { "Text" }
                }
                exitModal()
                if (isNew) selectTool(Tool.MOVE)
            },
            onCancel = {
                ui.removeCallbacks(pending)
                doc.cancelEdit()
                exitModal()
            })
    }
}
