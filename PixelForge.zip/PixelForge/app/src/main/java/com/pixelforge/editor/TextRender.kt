package com.pixelforge.editor

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface

/** Draws a [TextData] onto a transparent, document-sized bitmap (used by text layers). */
object TextRender {
    val families = listOf("Sans", "Serif", "Mono", "Casual")

    fun typeface(td: TextData): Typeface {
        var style = Typeface.NORMAL
        if (td.bold && td.italic) style = Typeface.BOLD_ITALIC
        else if (td.bold) style = Typeface.BOLD
        else if (td.italic) style = Typeface.ITALIC
        return when (td.family) {
            1 -> Typeface.create(Typeface.SERIF, style)
            2 -> Typeface.create(Typeface.MONOSPACE, style)
            3 -> Typeface.create("casual", style)
            else -> Typeface.create(Typeface.SANS_SERIF, style)
        }
    }

    fun render(td: TextData, w: Int, h: Int): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val size = td.size.coerceAtLeast(4f)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.typeface = typeface(td)
        p.textSize = size
        p.letterSpacing = td.spacing / 100f
        p.textAlign = when (td.align) {
            1 -> Paint.Align.CENTER
            2 -> Paint.Align.RIGHT
            else -> Paint.Align.LEFT
        }
        val lines = td.text.split("\n")
        val fm = p.fontMetrics
        val lineH = p.fontSpacing
        var base = td.y - fm.ascent
        for (line in lines) {
            if (td.strokeW > 0f) {
                val sp = Paint(p)
                sp.style = Paint.Style.STROKE
                sp.strokeWidth = td.strokeW * 2f
                sp.strokeJoin = Paint.Join.ROUND
                sp.color = td.strokeColor
                c.drawText(line, td.x, base, sp)
            }
            val fp = Paint(p)
            fp.style = Paint.Style.FILL
            fp.color = td.color
            if (td.shadow) fp.setShadowLayer(size * 0.08f, size * 0.05f, size * 0.05f, 0x99000000.toInt())
            c.drawText(line, td.x, base, fp)
            base += lineH
        }
        return bmp
    }
}
