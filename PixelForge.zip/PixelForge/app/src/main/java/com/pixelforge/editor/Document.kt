package com.pixelforge.editor

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import android.os.Build

/** Photoshop-style blend modes. Modes marked advanced need Android 10+ (BlendMode). */
enum class Blend(val label: String, val advanced: Boolean) {
    NORMAL("Normal", false),
    DARKEN("Darken", false),
    MULTIPLY("Multiply", false),
    COLOR_BURN("Color Burn", true),
    LIGHTEN("Lighten", false),
    SCREEN("Screen", false),
    COLOR_DODGE("Color Dodge", true),
    ADD("Linear Dodge (Add)", false),
    OVERLAY("Overlay", false),
    SOFT_LIGHT("Soft Light", true),
    HARD_LIGHT("Hard Light", true),
    DIFFERENCE("Difference", true),
    EXCLUSION("Exclusion", true),
    HUE("Hue", true),
    SATURATION("Saturation", true),
    COLOR("Color", true),
    LUMINOSITY("Luminosity", true);

    companion object {
        fun available(): List<Blend> =
            if (Build.VERSION.SDK_INT >= 29) values().toList() else values().filter { !it.advanced }
    }
}

fun Paint.setBlend(b: Blend) {
    if (Build.VERSION.SDK_INT >= 29) {
        xfermode = null
        blendMode = when (b) {
            Blend.NORMAL -> android.graphics.BlendMode.SRC_OVER
            Blend.DARKEN -> android.graphics.BlendMode.DARKEN
            Blend.MULTIPLY -> android.graphics.BlendMode.MULTIPLY
            Blend.COLOR_BURN -> android.graphics.BlendMode.COLOR_BURN
            Blend.LIGHTEN -> android.graphics.BlendMode.LIGHTEN
            Blend.SCREEN -> android.graphics.BlendMode.SCREEN
            Blend.COLOR_DODGE -> android.graphics.BlendMode.COLOR_DODGE
            Blend.ADD -> android.graphics.BlendMode.PLUS
            Blend.OVERLAY -> android.graphics.BlendMode.OVERLAY
            Blend.SOFT_LIGHT -> android.graphics.BlendMode.SOFT_LIGHT
            Blend.HARD_LIGHT -> android.graphics.BlendMode.HARD_LIGHT
            Blend.DIFFERENCE -> android.graphics.BlendMode.DIFFERENCE
            Blend.EXCLUSION -> android.graphics.BlendMode.EXCLUSION
            Blend.HUE -> android.graphics.BlendMode.HUE
            Blend.SATURATION -> android.graphics.BlendMode.SATURATION
            Blend.COLOR -> android.graphics.BlendMode.COLOR
            Blend.LUMINOSITY -> android.graphics.BlendMode.LUMINOSITY
        }
    } else {
        xfermode = when (b) {
            Blend.DARKEN -> PorterDuffXfermode(PorterDuff.Mode.DARKEN)
            Blend.MULTIPLY -> PorterDuffXfermode(PorterDuff.Mode.MULTIPLY)
            Blend.LIGHTEN -> PorterDuffXfermode(PorterDuff.Mode.LIGHTEN)
            Blend.SCREEN -> PorterDuffXfermode(PorterDuff.Mode.SCREEN)
            Blend.ADD -> PorterDuffXfermode(PorterDuff.Mode.ADD)
            Blend.OVERLAY -> PorterDuffXfermode(PorterDuff.Mode.OVERLAY)
            else -> null
        }
    }
}

/** Editable description of a text layer (kept so text can be re-edited until the layer is painted on). */
data class TextData(
    var text: String = "Your text",
    var size: Float = 110f,
    var color: Int = Color.WHITE,
    var bold: Boolean = true,
    var italic: Boolean = false,
    var family: Int = 0,
    var align: Int = 0,          // 0 left, 1 center, 2 right
    var x: Float = 0f,
    var y: Float = 0f,
    var strokeW: Float = 0f,
    var strokeColor: Int = Color.BLACK,
    var shadow: Boolean = false,
    var spacing: Float = 0f
)

class Layer(
    val id: Long,
    var name: String,
    var bitmap: Bitmap,
    var visible: Boolean = true,
    var opacity: Int = 100,
    var blend: Blend = Blend.NORMAL,
    var text: TextData? = null
)

class LayerState(
    val id: Long, val name: String, val bitmap: Bitmap, val visible: Boolean,
    val opacity: Int, val blend: Blend, val text: TextData?
)

/** Immutable snapshot used by undo/redo. Bitmaps inside a State are never mutated (copy-on-write editing). */
class State(val w: Int, val h: Int, val layers: List<LayerState>, val active: Int, val selection: Mask?)

class Document(var width: Int, var height: Int) {
    val layers = ArrayList<Layer>()
    var active = 0
    var selection: Mask? = null
    var version = 0
    var dirty = false
    private var idGen = 1L

    private val undoStack = ArrayDeque<State>()
    private val redoStack = ArrayDeque<State>()

    companion object {
        const val MAX_HISTORY = 24
        const val MAX_DIM = 2560
    }

    fun nextId(): Long = idGen++
    fun touch() { version++ }
    fun canUndo() = undoStack.isNotEmpty()
    fun canRedo() = redoStack.isNotEmpty()

    fun activeLayer(): Layer = layers[active.coerceIn(0, layers.size - 1)]

    // ---------------------------------------------------------------- history

    private fun capture(): State = State(
        width, height,
        layers.map { LayerState(it.id, it.name, it.bitmap, it.visible, it.opacity, it.blend, it.text?.copy()) },
        active, selection
    )

    private fun restore(s: State) {
        width = s.w; height = s.h
        layers.clear()
        for (l in s.layers) layers.add(Layer(l.id, l.name, l.bitmap, l.visible, l.opacity, l.blend, l.text?.copy()))
        active = s.active.coerceIn(0, layers.size - 1)
        selection = s.selection
        touch()
    }

    /** Record the current state so the next change can be undone. */
    fun pushUndo() {
        undoStack.addLast(capture())
        redoStack.clear()
        while (undoStack.size > MAX_HISTORY) undoStack.removeFirst()
        dirty = true
    }

    fun undo(): Boolean {
        if (undoStack.isEmpty()) return false
        redoStack.addLast(capture())
        restore(undoStack.removeLast())
        return true
    }

    fun redo(): Boolean {
        if (redoStack.isEmpty()) return false
        undoStack.addLast(capture())
        restore(redoStack.removeLast())
        return true
    }

    /** Drop the most recent history entry and go back to it (used when a dialog / gesture is cancelled). */
    fun cancelEdit() {
        if (undoStack.isNotEmpty()) restore(undoStack.removeLast())
    }

    /**
     * Start an in-place pixel edit on the active layer. Returns the frozen original bitmap;
     * the layer now owns a fresh mutable copy that tools may draw into.
     */
    fun beginEdit(keepText: Boolean = false): Bitmap {
        val l = activeLayer()
        pushUndo()
        val old = l.bitmap
        l.bitmap = old.copy(Bitmap.Config.ARGB_8888, true)
            ?: throw OutOfMemoryError("Could not copy layer")
        if (!keepText) l.text = null
        touch()
        return old
    }

    // ---------------------------------------------------------------- layers

    private fun newBitmap(): Bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)

    fun addLayer(name: String, fill: Int = 0): Layer {
        pushUndo()
        val bmp = newBitmap()
        if (fill != 0) bmp.eraseColor(fill)
        val l = Layer(nextId(), name, bmp)
        val at = if (layers.isEmpty()) 0 else active + 1
        layers.add(at, l)
        active = at
        touch()
        return l
    }

    fun addBitmapLayer(name: String, bmp: Bitmap): Layer {
        pushUndo()
        val l = Layer(nextId(), name, bmp)
        val at = if (layers.isEmpty()) 0 else active + 1
        layers.add(at, l)
        active = at
        touch()
        return l
    }

    fun duplicateActive() {
        pushUndo()
        val src = activeLayer()
        val l = Layer(nextId(), src.name + " copy", src.bitmap.copy(Bitmap.Config.ARGB_8888, true)!!,
            src.visible, src.opacity, src.blend, src.text?.copy())
        layers.add(active + 1, l)
        active += 1
        touch()
    }

    fun deleteActive(): Boolean {
        if (layers.size <= 1) return false
        pushUndo()
        layers.removeAt(active)
        active = active.coerceIn(0, layers.size - 1)
        touch()
        return true
    }

    fun moveActive(delta: Int) {
        val to = active + delta
        if (to < 0 || to >= layers.size) return
        pushUndo()
        val l = layers.removeAt(active)
        layers.add(to, l)
        active = to
        touch()
    }

    fun mergeDown(): Boolean {
        if (active <= 0) return false
        pushUndo()
        val top = layers[active]
        val low = layers[active - 1]
        val bmp = newBitmap()
        val c = Canvas(bmp)
        val p = Paint(Paint.FILTER_BITMAP_FLAG)
        p.alpha = low.opacity * 255 / 100
        p.setBlend(Blend.NORMAL)
        if (low.visible) c.drawBitmap(low.bitmap, 0f, 0f, p)
        p.alpha = top.opacity * 255 / 100
        p.setBlend(top.blend)
        if (top.visible) c.drawBitmap(top.bitmap, 0f, 0f, p)
        val merged = Layer(nextId(), low.name, bmp)
        layers.removeAt(active)
        layers[active - 1] = merged
        active -= 1
        touch()
        return true
    }

    fun flatten() {
        if (layers.size <= 1) return
        pushUndo()
        val bmp = newBitmap()
        Compositor.render(this, bmp)
        val l = Layer(nextId(), "Background", bmp)
        layers.clear()
        layers.add(l)
        active = 0
        touch()
    }

    fun commitSelection(m: Mask?) {
        pushUndo()
        selection = m
        touch()
    }

    /** Layer property change that should be undoable (opacity, blend, visibility, name). */
    fun changeProps(action: (Layer) -> Unit) {
        pushUndo()
        action(activeLayer())
        touch()
    }

    // ---------------------------------------------------------------- whole-canvas transforms

    fun transformCanvas(newW: Int, newH: Int, m: Matrix, filter: Boolean = true) {
        pushUndo()
        val p = Paint(Paint.FILTER_BITMAP_FLAG)
        p.isFilterBitmap = filter
        for (l in layers) {
            val nb = Bitmap.createBitmap(newW, newH, Bitmap.Config.ARGB_8888)
            Canvas(nb).drawBitmap(l.bitmap, m, p)
            l.bitmap = nb
            l.text = null
        }
        width = newW; height = newH
        selection = null
        touch()
    }

    fun crop(r: Rect) {
        val rr = Rect(r)
        if (!rr.intersect(0, 0, width, height) || rr.width() < 1 || rr.height() < 1) return
        val m = Matrix()
        m.setTranslate(-rr.left.toFloat(), -rr.top.toFloat())
        transformCanvas(rr.width(), rr.height(), m, false)
    }

    fun resizeImage(newW: Int, newH: Int) {
        val m = Matrix()
        m.setScale(newW.toFloat() / width, newH.toFloat() / height)
        transformCanvas(newW, newH, m, true)
    }

    fun resizeCanvas(newW: Int, newH: Int) {
        val m = Matrix()
        m.setTranslate((newW - width) / 2f, (newH - height) / 2f)
        transformCanvas(newW, newH, m, false)
    }

    fun rotate(deg: Int) {
        val m = Matrix()
        when (((deg % 360) + 360) % 360) {
            90 -> { m.setRotate(90f); m.postTranslate(height.toFloat(), 0f); transformCanvas(height, width, m, false) }
            270 -> { m.setRotate(-90f); m.postTranslate(0f, width.toFloat()); transformCanvas(height, width, m, false) }
            180 -> { m.setRotate(180f); m.postTranslate(width.toFloat(), height.toFloat()); transformCanvas(width, height, m, false) }
        }
    }

    fun flip(horizontal: Boolean) {
        val m = Matrix()
        if (horizontal) { m.setScale(-1f, 1f); m.postTranslate(width.toFloat(), 0f) }
        else { m.setScale(1f, -1f); m.postTranslate(0f, height.toFloat()) }
        transformCanvas(width, height, m, false)
    }

    /** Flip / rotate just the active layer around the canvas centre. */
    fun transformActiveLayer(m: Matrix) {
        pushUndo()
        val l = activeLayer()
        val nb = newBitmap()
        Canvas(nb).drawBitmap(l.bitmap, m, Paint(Paint.FILTER_BITMAP_FLAG))
        l.bitmap = nb
        l.text = null
        touch()
    }

    /**
     * Draw onto the active layer through the current selection. The lambda draws into a transparent
     * scratch canvas; the result is masked by the selection and composited (or erased) onto the layer.
     */
    fun paintOnActive(erase: Boolean = false, alpha: Int = 255, draw: (Canvas) -> Unit) {
        val old = beginEdit()
        val layer = activeLayer()
        val tmp = newBitmap()
        draw(Canvas(tmp))
        val sel = selection
        if (sel != null) {
            val mp = Paint()
            mp.xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
            Canvas(tmp).drawBitmap(sel.bitmap(), 0f, 0f, mp)
        }
        val p = Paint()
        p.alpha = alpha
        if (erase) p.xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT)
        Canvas(layer.bitmap).drawBitmap(tmp, 0f, 0f, p)
        tmp.recycle()
        touch()
    }
}

object Compositor {
    private val p = Paint(Paint.FILTER_BITMAP_FLAG)

    fun render(
        doc: Document, out: Bitmap, clear: Boolean = true,
        liveLayer: Layer? = null, liveMatrix: Matrix? = null, filter: Boolean = true
    ) {
        val c = Canvas(out)
        if (clear) out.eraseColor(0)
        for (l in doc.layers) {
            if (!l.visible) continue
            p.alpha = l.opacity * 255 / 100
            p.setBlend(l.blend)
            p.isFilterBitmap = filter
            if (l === liveLayer && liveMatrix != null) c.drawBitmap(l.bitmap, liveMatrix, p)
            else c.drawBitmap(l.bitmap, 0f, 0f, p)
        }
    }
}

enum class SelMode { NEW, ADD, SUBTRACT, INTERSECT }
enum class ShapeType { LINE, RECT, ROUNDRECT, ELLIPSE }

enum class Tool(val label: String, val icon: String, val group: String) {
    MOVE("Move", "✥", "View"),
    TRANSFORM("Transform", "⤡", "View"),
    HAND("Pan", "✋", "View"),
    EYEDROPPER("Picker", "💧", "View"),

    MARQUEE_RECT("Rect Select", "⬚", "Select"),
    MARQUEE_ELLIPSE("Oval Select", "◌", "Select"),
    LASSO("Lasso", "➰", "Select"),
    WAND("Magic Wand", "🪄", "Select"),
    SELECT_BRUSH("Select Brush", "🖍", "Select"),
    CROP("Crop", "⛶", "Select"),

    BRUSH("Brush", "🖌", "Paint"),
    ERASER("Eraser", "⌫", "Paint"),
    BUCKET("Fill", "🪣", "Paint"),
    GRADIENT("Gradient", "🌈", "Paint"),
    SHAPE("Shapes", "△", "Paint"),
    TEXT("Text", "T", "Paint"),

    CLONE("Clone", "⎘", "Retouch"),
    HEAL("Heal", "✚", "Retouch"),
    SPOT("Spot Heal", "◉", "Retouch"),
    SMUDGE("Smudge", "☝", "Retouch"),
    BLUR_BRUSH("Blur", "◔", "Retouch"),
    SHARPEN_BRUSH("Sharpen", "◭", "Retouch"),
    DODGE("Dodge", "☀", "Retouch"),
    BURN("Burn", "☾", "Retouch"),
    SPONGE("Sponge", "❖", "Retouch"),
    REDEYE("Red Eye", "👁", "Retouch");

    val isStroke: Boolean get() = this == BRUSH || this == ERASER
    val isRetouch: Boolean get() = group == "Retouch"
}

/** Shared tool settings. */
object ToolOpts {
    var fg = Color.BLACK
    var bg = Color.WHITE
    var size = 40f
    var hardness = 0.7f
    var opacity = 1f
    var strength = 0.5f
    var smoothing = 0.25f
    var pressure = true
    var tolerance = 32
    var contiguous = true
    var sampleAll = false
    var selMode = SelMode.NEW
    var shape = ShapeType.RECT
    var shapeFill = false
    var shapeStroke = 8f
    var gradRadial = false
    var gradToTransparent = false
}
