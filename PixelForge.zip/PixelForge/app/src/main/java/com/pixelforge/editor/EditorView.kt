package com.pixelforge.editor

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** The canvas: draws the composited document, handles zoom/pan and routes touches to the active tool. */
class EditorView(ctx: Context) : View(ctx) {

    interface Listener {
        fun onChanged(structural: Boolean)
        fun onColorPicked(c: Int)
        fun onTextTap(x: Float, y: Float)
        fun onCropState(active: Boolean)
        fun onMessage(s: String)
        fun onZoom(pct: Int)
    }

    var listener: Listener? = null
    var doc: Document = Document(1080, 1080)
        private set

    private var comp: Bitmap? = null
    private var compVersion = -1
    private var forceComp = true
    private val vm = Matrix()
    private val inv = Matrix()
    private var scale = 1f
    private var needFit = true

    var tool: Tool = Tool.BRUSH
        set(v) {
            cancelGesture()
            field = v
            if (v == Tool.CROP) beginCrop() else if (cropRect != null) { cropRect = null; listener?.onCropState(false) }
            invalidate()
        }

    // gesture state
    private var multi = false
    private var ignoreRest = false
    private var down = false
    private var curSX = 0f
    private var curSY = 0f
    private var mx = 0f
    private var my = 0f
    private var md = 1f
    private var ma = 0f
    private var lastDoc = PointF()
    private var dragStart: PointF? = null
    private var dragCur: PointF? = null
    private var lasso: Path? = null
    private var selPath: Path? = null
    private var liveMatrix: Matrix? = null
    private var stroke: StrokeEngine? = null
    private var retouch: RetouchEngine? = null
    private var movedFar = false
    private var downSX = 0f
    private var downSY = 0f
    var settingCloneSource = false

    // crop
    var cropRect: RectF? = null
        private set
    private var cropFlags = 0
    private val CL = 1; private val CT = 2; private val CR = 4; private val CB = 8
    private val CMOVE = 16; private val CNEW = 32
    private var cropAnchor = PointF()

    // paints
    private val compPaint = Paint()
    private val checkerPaint = Paint()
    private val ov = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val dim = Paint().apply { color = 0x99000000.toInt() }
    private val cursorPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }

    init {
        val tile = Bitmap.createBitmap(16, 16, Bitmap.Config.ARGB_8888)
        val tc = Canvas(tile)
        val p = Paint()
        p.color = 0xFFE4E4E8.toInt(); tc.drawRect(0f, 0f, 16f, 16f, p)
        p.color = 0xFFC6C6CC.toInt(); tc.drawRect(0f, 0f, 8f, 8f, p); tc.drawRect(8f, 8f, 16f, 16f, p)
        checkerPaint.shader = BitmapShader(tile, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
        isFocusable = true
    }

    // ------------------------------------------------------------------ document / view

    fun setDocument(d: Document) {
        cancelGesture()
        doc = d
        comp = null
        forceComp = true
        cropRect = null
        fit()
    }

    fun refresh() {
        doc.touch()
        invalidate()
    }

    fun redrawComp() {
        forceComp = true
        invalidate()
    }

    fun fit() {
        if (width == 0 || height == 0) { needFit = true; return }
        needFit = false
        val pad = ctxDp(14f)
        val s = min((width - pad * 2f) / doc.width, (height - pad * 2f) / doc.height).coerceAtLeast(0.02f)
        vm.reset()
        vm.postScale(s, s)
        vm.postTranslate((width - doc.width * s) / 2f, (height - doc.height * s) / 2f)
        updateMatrix()
    }

    fun zoomActual() {
        val c = toDoc(width / 2f, height / 2f)
        vm.reset()
        vm.postScale(1f, 1f)
        vm.postTranslate(width / 2f - c.x, height / 2f - c.y)
        updateMatrix()
    }

    private fun ctxDp(v: Float) = v * resources.displayMetrics.density

    private fun updateMatrix() {
        vm.invert(inv)
        val v = FloatArray(9)
        vm.getValues(v)
        scale = v[Matrix.MSCALE_X]
        listener?.onZoom((scale * 100).roundToInt())
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        if (needFit || ow == 0) fit()
    }

    fun toDoc(x: Float, y: Float): PointF {
        val p = floatArrayOf(x, y)
        inv.mapPoints(p)
        return PointF(p[0], p[1])
    }

    // ------------------------------------------------------------------ drawing

    private fun ensureComp() {
        var c = comp
        if (c == null || c.width != doc.width || c.height != doc.height) {
            c = Bitmap.createBitmap(doc.width, doc.height, Bitmap.Config.ARGB_8888)
            comp = c
            forceComp = true
        }
        if (forceComp || compVersion != doc.version) {
            val lm = liveMatrix
            Compositor.render(doc, c, true, if (lm != null) doc.activeLayer() else null, lm, true)
            compVersion = doc.version
            forceComp = false
        }
    }

    private fun outline(c: Canvas, draw: (Paint) -> Unit) {
        ov.pathEffect = null
        ov.color = Color.BLACK
        ov.strokeWidth = 3f / scale
        draw(ov)
        ov.color = Color.WHITE
        ov.strokeWidth = 1.5f / scale
        ov.pathEffect = DashPathEffect(floatArrayOf(6f / scale, 6f / scale), 0f)
        draw(ov)
        ov.pathEffect = null
    }

    override fun onDraw(c: Canvas) {
        c.drawColor(0xFF111114.toInt())
        ensureComp()
        val bmp = comp ?: return
        c.save()
        c.concat(vm)
        val dw = doc.width.toFloat()
        val dh = doc.height.toFloat()
        val sm = Matrix()
        sm.setScale(1f / scale, 1f / scale)
        checkerPaint.shader.setLocalMatrix(sm)
        c.drawRect(0f, 0f, dw, dh, checkerPaint)
        compPaint.isFilterBitmap = scale < 2f
        c.drawBitmap(bmp, 0f, 0f, compPaint)

        doc.selection?.let { c.drawBitmap(it.edges(), 0f, 0f, null) }

        // tool overlays
        val s = dragStart
        val e = dragCur
        when (tool) {
            Tool.MARQUEE_RECT -> if (s != null && e != null) outline(c) { p -> c.drawRect(min(s.x, e.x), min(s.y, e.y), max(s.x, e.x), max(s.y, e.y), p) }
            Tool.MARQUEE_ELLIPSE -> if (s != null && e != null) outline(c) { p -> c.drawOval(RectF(min(s.x, e.x), min(s.y, e.y), max(s.x, e.x), max(s.y, e.y)), p) }
            Tool.LASSO -> lasso?.let { lp -> outline(c) { p -> c.drawPath(lp, p) } }
            Tool.SELECT_BRUSH -> selPath?.let { sp ->
                val p = Paint(Paint.ANTI_ALIAS_FLAG)
                p.style = Paint.Style.STROKE
                p.strokeWidth = ToolOpts.size
                p.strokeCap = Paint.Cap.ROUND
                p.strokeJoin = Paint.Join.ROUND
                p.color = 0x6631A8FF
                c.drawPath(sp, p)
            }
            Tool.SHAPE -> if (s != null && e != null) {
                val l = min(s.x, e.x); val t = min(s.y, e.y); val r = max(s.x, e.x); val b = max(s.y, e.y)
                outline(c) { p ->
                    when (ToolOpts.shape) {
                        ShapeType.LINE -> c.drawLine(s.x, s.y, e.x, e.y, p)
                        ShapeType.RECT -> c.drawRect(l, t, r, b, p)
                        ShapeType.ROUNDRECT -> c.drawRoundRect(RectF(l, t, r, b), min(r - l, b - t) * 0.18f, min(r - l, b - t) * 0.18f, p)
                        ShapeType.ELLIPSE -> c.drawOval(RectF(l, t, r, b), p)
                    }
                }
            }
            Tool.GRADIENT -> if (s != null && e != null) {
                outline(c) { p -> c.drawLine(s.x, s.y, e.x, e.y, p) }
                dotPaint.color = ToolOpts.fg
                c.drawCircle(s.x, s.y, 7f / scale, dotPaint)
                dotPaint.color = ToolOpts.bg
                c.drawCircle(e.x, e.y, 7f / scale, dotPaint)
            }
            Tool.CROP -> drawCrop(c)
            Tool.CLONE, Tool.HEAL -> RetouchEngine.cloneSource?.let { cs ->
                outline(c) { p ->
                    c.drawCircle(cs.x, cs.y, 14f / scale, p)
                    c.drawLine(cs.x - 20f / scale, cs.y, cs.x + 20f / scale, cs.y, p)
                    c.drawLine(cs.x, cs.y - 20f / scale, cs.x, cs.y + 20f / scale, p)
                }
            }
            else -> {}
        }
        c.restore()

        // brush cursor
        if (down && !multi && (tool.isStroke || tool.isRetouch || tool == Tool.SELECT_BRUSH)) {
            val r = ToolOpts.size / 2f * scale
            cursorPaint.color = Color.BLACK; cursorPaint.strokeWidth = 3f
            c.drawCircle(curSX, curSY, r, cursorPaint)
            cursorPaint.color = Color.WHITE; cursorPaint.strokeWidth = 1.5f
            c.drawCircle(curSX, curSY, r, cursorPaint)
        }
    }

    private fun drawCrop(c: Canvas) {
        val r = cropRect ?: return
        val dw = doc.width.toFloat(); val dh = doc.height.toFloat()
        c.drawRect(0f, 0f, dw, r.top, dim)
        c.drawRect(0f, r.bottom, dw, dh, dim)
        c.drawRect(0f, r.top, r.left, r.bottom, dim)
        c.drawRect(r.right, r.top, dw, r.bottom, dim)
        ov.pathEffect = null
        ov.color = Color.WHITE
        ov.strokeWidth = 2f / scale
        c.drawRect(r, ov)
        ov.strokeWidth = 1f / scale
        ov.color = 0x88FFFFFF.toInt()
        for (i in 1..2) {
            c.drawLine(r.left + r.width() * i / 3f, r.top, r.left + r.width() * i / 3f, r.bottom, ov)
            c.drawLine(r.left, r.top + r.height() * i / 3f, r.right, r.top + r.height() * i / 3f, ov)
        }
        dotPaint.color = Color.WHITE
        val hr = 7f / scale
        for (x in floatArrayOf(r.left, r.right)) for (y in floatArrayOf(r.top, r.bottom)) c.drawCircle(x, y, hr, dotPaint)
    }

    // ------------------------------------------------------------------ crop API

    fun beginCrop() {
        cropRect = RectF(0f, 0f, doc.width.toFloat(), doc.height.toFloat())
        listener?.onCropState(true)
        invalidate()
    }

    fun cancelCrop() {
        cropRect = null
        listener?.onCropState(false)
        invalidate()
    }

    fun applyCrop() {
        val r = cropRect ?: return
        val ir = Rect(r.left.roundToInt(), r.top.roundToInt(), r.right.roundToInt(), r.bottom.roundToInt())
        cropRect = null
        if (ir.width() >= 2 && ir.height() >= 2) {
            doc.crop(ir)
            fit()
            listener?.onChanged(true)
        }
        listener?.onCropState(false)
        invalidate()
    }

    /** Fit the largest centred rect with the given aspect (w/h) inside the image. Null = free (full image). */
    fun setCropAspect(aspect: Float?) {
        val dw = doc.width.toFloat(); val dh = doc.height.toFloat()
        if (aspect == null) { cropRect = RectF(0f, 0f, dw, dh); invalidate(); return }
        var w = dw
        var h = w / aspect
        if (h > dh) { h = dh; w = h * aspect }
        cropRect = RectF((dw - w) / 2f, (dh - h) / 2f, (dw + w) / 2f, (dh + h) / 2f)
        invalidate()
    }

    // ------------------------------------------------------------------ touch

    private fun pressureOf(e: MotionEvent): Float =
        if (e.getToolType(0) == MotionEvent.TOOL_TYPE_STYLUS) e.pressure.coerceIn(0.05f, 1f) else 1f

    private fun layerBlocked(): Boolean {
        if (!doc.activeLayer().visible) {
            listener?.onMessage("This layer is hidden — show it first")
            return true
        }
        return false
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                multi = false
                ignoreRest = false
                downSX = e.x; downSY = e.y
                curSX = e.x; curSY = e.y
                lastScreenX = e.x; lastScreenY = e.y
                movedFar = false
                touchDown(e.x, e.y, pressureOf(e))
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                if (!multi) {
                    multi = true
                    if (!(tool == Tool.TRANSFORM && liveMatrix != null)) cancelGesture()
                }
                if (e.pointerCount >= 2) multiStart(e)
            }
            MotionEvent.ACTION_MOVE -> {
                if (multi) {
                    if (e.pointerCount >= 2) multiMove(e)
                } else if (!ignoreRest) {
                    curSX = e.x; curSY = e.y
                    if (hypot(e.x - downSX, e.y - downSY) > ctxDp(8f)) movedFar = true
                    touchMove(e)
                }
            }
            MotionEvent.ACTION_POINTER_UP -> {
                if (multi) multiEnd()
                multi = false
                ignoreRest = true
            }
            MotionEvent.ACTION_UP -> {
                if (multi) multiEnd()
                else if (!ignoreRest) touchUp(e.x, e.y)
                multi = false
                ignoreRest = false
                down = false
                invalidate()
            }
            MotionEvent.ACTION_CANCEL -> {
                cancelGesture()
                multi = false
                ignoreRest = false
                down = false
            }
        }
        return true
    }

    private fun multiStart(e: MotionEvent) {
        mx = (e.getX(0) + e.getX(1)) / 2f
        my = (e.getY(0) + e.getY(1)) / 2f
        val dx = e.getX(1) - e.getX(0); val dy = e.getY(1) - e.getY(0)
        md = max(1f, hypot(dx, dy))
        ma = atan2(dy, dx)
    }

    private fun multiMove(e: MotionEvent) {
        val nx = (e.getX(0) + e.getX(1)) / 2f
        val ny = (e.getY(0) + e.getY(1)) / 2f
        val dx = e.getX(1) - e.getX(0); val dy = e.getY(1) - e.getY(0)
        val nd = max(1f, hypot(dx, dy))
        val na = atan2(dy, dx)
        if (tool == Tool.TRANSFORM) {
            val p0 = toDoc(mx, my)
            val p1 = toDoc(nx, ny)
            val m = liveMatrix ?: Matrix().also { liveMatrix = it }
            var da = na - ma
            while (da > Math.PI) da -= (2 * Math.PI).toFloat()
            while (da < -Math.PI) da += (2 * Math.PI).toFloat()
            val s = nd / md
            m.postScale(s, s, p0.x, p0.y)
            m.postRotate(Math.toDegrees(da.toDouble()).toFloat(), p0.x, p0.y)
            m.postTranslate(p1.x - p0.x, p1.y - p0.y)
            redrawComp()
        } else {
            var s = nd / md
            val ns = scale * s
            if (ns < 0.03f) s = 0.03f / scale
            if (ns > 48f) s = 48f / scale
            vm.postTranslate(nx - mx, ny - my)
            vm.postScale(s, s, nx, ny)
            updateMatrix()
        }
        mx = nx; my = ny; md = nd; ma = na
    }

    private fun multiEnd() {
        if (tool == Tool.TRANSFORM && liveMatrix != null) bakeLive()
    }

    private fun cancelGesture() {
        stroke?.let { it.end(); doc.cancelEdit() }
        stroke = null
        retouch?.let { it.end(); doc.cancelEdit() }
        retouch = null
        liveMatrix = null
        dragStart = null; dragCur = null
        lasso = null; selPath = null
        down = false
        forceComp = true
        invalidate()
    }

    private fun touchDown(sx: Float, sy: Float, pressure: Float) {
        val p = toDoc(sx, sy)
        lastDoc = p
        down = true
        try {
            when (tool) {
                Tool.HAND -> {}
                Tool.MOVE, Tool.TRANSFORM -> { liveMatrix = Matrix() }
                Tool.EYEDROPPER -> pick(p)
                Tool.MARQUEE_RECT, Tool.MARQUEE_ELLIPSE, Tool.GRADIENT, Tool.SHAPE -> {
                    if ((tool == Tool.GRADIENT || tool == Tool.SHAPE) && layerBlocked()) { down = false; ignoreRest = true; return }
                    dragStart = p; dragCur = p
                }
                Tool.LASSO -> lasso = Path().apply { moveTo(p.x, p.y) }
                Tool.SELECT_BRUSH -> selPath = Path().apply { moveTo(p.x, p.y); lineTo(p.x + 0.01f, p.y) }
                Tool.CROP -> cropDown(p)
                Tool.BRUSH, Tool.ERASER -> {
                    if (layerBlocked()) { down = false; ignoreRest = true; return }
                    val s = StrokeEngine(doc)
                    s.begin(tool == Tool.ERASER)
                    stroke = s
                    s.add(p.x, p.y, pressure)
                    redrawComp()
                }
                Tool.CLONE, Tool.HEAL -> {
                    if (settingCloneSource) {
                        RetouchEngine.cloneSource = p
                        RetouchEngine.cloneOffset = null
                        settingCloneSource = false
                        listener?.onMessage("Source set — now paint where you want the copy")
                        down = false; ignoreRest = true
                        invalidate()
                        return
                    }
                    if (RetouchEngine.cloneSource == null) {
                        listener?.onMessage("Tap “Set source”, then tap the area you want to copy from")
                        down = false; ignoreRest = true
                        return
                    }
                    if (layerBlocked()) { down = false; ignoreRest = true; return }
                    startRetouch(p)
                }
                Tool.SPOT, Tool.SMUDGE, Tool.BLUR_BRUSH, Tool.SHARPEN_BRUSH, Tool.DODGE, Tool.BURN, Tool.SPONGE, Tool.REDEYE -> {
                    if (layerBlocked()) { down = false; ignoreRest = true; return }
                    startRetouch(p)
                }
                Tool.BUCKET, Tool.WAND, Tool.TEXT -> {}
            }
        } catch (oom: OutOfMemoryError) {
            listener?.onMessage("Not enough memory for that operation")
            cancelGesture()
            ignoreRest = true
        }
        invalidate()
    }

    private fun startRetouch(p: PointF) {
        val r = RetouchEngine(doc)
        r.begin(tool, p.x, p.y)
        retouch = r
        redrawComp()
    }

    private fun touchMove(e: MotionEvent) {
        val p = toDoc(e.x, e.y)
        when (tool) {
            Tool.HAND -> {
                vm.postTranslate(e.x - lastScreenX, e.y - lastScreenY)
                updateMatrix()
            }
            Tool.MOVE, Tool.TRANSFORM -> {
                liveMatrix?.postTranslate(p.x - lastDoc.x, p.y - lastDoc.y)
                redrawComp()
            }
            Tool.EYEDROPPER -> pick(p)
            Tool.MARQUEE_RECT, Tool.MARQUEE_ELLIPSE, Tool.GRADIENT, Tool.SHAPE -> { dragCur = p }
            Tool.LASSO -> lasso?.lineTo(p.x, p.y)
            Tool.SELECT_BRUSH -> selPath?.lineTo(p.x, p.y)
            Tool.CROP -> cropDrag(p)
            Tool.BRUSH, Tool.ERASER -> {
                val s = stroke
                if (s != null) {
                    for (i in 0 until e.historySize) {
                        val h = toDoc(e.getHistoricalX(i), e.getHistoricalY(i))
                        val hp = if (e.getToolType(0) == MotionEvent.TOOL_TYPE_STYLUS) e.getHistoricalPressure(i).coerceIn(0.05f, 1f) else 1f
                        s.add(h.x, h.y, hp)
                    }
                    s.add(p.x, p.y, pressureOf(e))
                    redrawComp()
                }
            }
            else -> {
                val r = retouch
                if (r != null) {
                    for (i in 0 until e.historySize) {
                        val h = toDoc(e.getHistoricalX(i), e.getHistoricalY(i))
                        r.add(h.x, h.y)
                    }
                    r.add(p.x, p.y)
                    redrawComp()
                }
            }
        }
        lastDoc = p
        lastScreenX = e.x; lastScreenY = e.y
        invalidate()
    }

    private var lastScreenX = 0f
    private var lastScreenY = 0f

    private fun touchUp(sx: Float, sy: Float) {
        val p = toDoc(sx, sy)
        try {
            when (tool) {
                Tool.MOVE, Tool.TRANSFORM -> bakeLive()
                Tool.MARQUEE_RECT -> {
                    val s = dragStart
                    if (s != null && abs(p.x - s.x) > 1 && abs(p.y - s.y) > 1) {
                        commitSelection(Mask.rect(doc.width, doc.height, RectF(min(s.x, p.x), min(s.y, p.y), max(s.x, p.x), max(s.y, p.y))))
                    } else if (s != null) clearSelectionIfTap()
                }
                Tool.MARQUEE_ELLIPSE -> {
                    val s = dragStart
                    if (s != null && abs(p.x - s.x) > 1 && abs(p.y - s.y) > 1) {
                        commitSelection(Mask.ellipse(doc.width, doc.height, RectF(min(s.x, p.x), min(s.y, p.y), max(s.x, p.x), max(s.y, p.y))))
                    } else if (s != null) clearSelectionIfTap()
                }
                Tool.LASSO -> {
                    val lp = lasso
                    if (lp != null && movedFar) {
                        lp.close()
                        commitSelection(Mask.fromPath(doc.width, doc.height, lp))
                    }
                }
                Tool.SELECT_BRUSH -> {
                    val sp = selPath
                    if (sp != null) {
                        val m = Mask.fromPath(doc.width, doc.height, sp, max(1f, ToolOpts.size))
                        val mode = if (ToolOpts.selMode == SelMode.NEW) SelMode.ADD else ToolOpts.selMode
                        val combined = Mask.combine(doc.selection, m, mode)
                        doc.commitSelection(if (combined.isEmpty()) null else combined)
                        listener?.onChanged(false)
                    }
                }
                Tool.WAND -> {
                    val x = p.x.toInt(); val y = p.y.toInt()
                    if (x in 0 until doc.width && y in 0 until doc.height) {
                        val px = samplePixels()
                        val m = Mask.wand(px, doc.width, doc.height, x, y, ToolOpts.tolerance, ToolOpts.contiguous)
                        commitSelection(m)
                    }
                }
                Tool.BRUSH, Tool.ERASER -> {
                    stroke?.end()
                    stroke = null
                    listener?.onChanged(false)
                }
                Tool.BUCKET -> {
                    if (!layerBlocked()) {
                        FillOps.bucket(doc, p.x.toInt(), p.y.toInt())
                        listener?.onChanged(false)
                    }
                }
                Tool.GRADIENT -> {
                    val s = dragStart
                    if (s != null) { FillOps.gradient(doc, s.x, s.y, p.x, p.y); listener?.onChanged(false) }
                }
                Tool.SHAPE -> {
                    val s = dragStart
                    if (s != null) { FillOps.shape(doc, ToolOpts.shape, s.x, s.y, p.x, p.y); listener?.onChanged(false) }
                }
                Tool.TEXT -> if (!movedFar) listener?.onTextTap(p.x, p.y)
                Tool.CROP -> { cropFlags = 0 }
                Tool.HAND, Tool.EYEDROPPER -> {}
                else -> {
                    val r = retouch
                    if (r != null) { r.end(); retouch = null; listener?.onChanged(false) }
                }
            }
        } catch (oom: OutOfMemoryError) {
            listener?.onMessage("Not enough memory for that operation")
        }
        dragStart = null; dragCur = null
        lasso = null; selPath = null
        forceComp = true
        invalidate()
    }

    private fun clearSelectionIfTap() {
        if (doc.selection != null) {
            doc.commitSelection(null)
            listener?.onChanged(false)
        }
    }

    private fun commitSelection(m: Mask) {
        val combined = Mask.combine(doc.selection, m, ToolOpts.selMode)
        doc.commitSelection(if (combined.isEmpty()) null else combined)
        listener?.onChanged(false)
    }

    private fun samplePixels(): IntArray {
        val w = doc.width; val h = doc.height
        val a = IntArray(w * h)
        if (ToolOpts.sampleAll) {
            val tmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            Compositor.render(doc, tmp)
            tmp.getPixels(a, 0, w, 0, 0, w, h)
            tmp.recycle()
        } else doc.activeLayer().bitmap.getPixels(a, 0, w, 0, 0, w, h)
        return a
    }

    private fun pick(p: PointF) {
        val c = comp ?: return
        val x = p.x.toInt(); val y = p.y.toInt()
        if (x < 0 || y < 0 || x >= c.width || y >= c.height) return
        val col = c.getPixel(x, y)
        if ((col ushr 24) == 0) return
        listener?.onColorPicked(col or -0x1000000)
    }

    // ------------------------------------------------------------------ move / transform bake

    private fun bakeLive() {
        val m = liveMatrix ?: return
        liveMatrix = null
        val v = FloatArray(9)
        m.getValues(v)
        val pureMove = abs(v[Matrix.MSCALE_X] - 1f) < 1e-4f && abs(v[Matrix.MSCALE_Y] - 1f) < 1e-4f &&
                abs(v[Matrix.MSKEW_X]) < 1e-4f && abs(v[Matrix.MSKEW_Y]) < 1e-4f
        if (pureMove && abs(v[Matrix.MTRANS_X]) < 0.5f && abs(v[Matrix.MTRANS_Y]) < 0.5f) { redrawComp(); return }
        doc.pushUndo()
        val layer = doc.activeLayer()
        val td = layer.text
        val nb = Bitmap.createBitmap(doc.width, doc.height, Bitmap.Config.ARGB_8888)
        val p = Paint()
        if (pureMove) {
            val mm = Matrix()
            mm.setTranslate(v[Matrix.MTRANS_X].roundToInt().toFloat(), v[Matrix.MTRANS_Y].roundToInt().toFloat())
            Canvas(nb).drawBitmap(layer.bitmap, mm, p)
            if (td != null) { td.x += mm.let { val a = FloatArray(9); it.getValues(a); a[Matrix.MTRANS_X] }; td.y += v[Matrix.MTRANS_Y].roundToInt() }
        } else {
            p.isFilterBitmap = true
            Canvas(nb).drawBitmap(layer.bitmap, m, p)
            layer.text = null
        }
        layer.bitmap = nb
        doc.touch()
        redrawComp()
        listener?.onChanged(false)
    }

    // ------------------------------------------------------------------ crop touch

    private fun cropDown(p: PointF) {
        val r = cropRect
        if (r == null) { beginCrop(); return }
        val h = ctxDp(30f) / scale
        val nearX = p.y > r.top - h && p.y < r.bottom + h
        val nearY = p.x > r.left - h && p.x < r.right + h
        var f = 0
        if (nearX && abs(p.x - r.left) < h) f = f or CL
        if (nearX && abs(p.x - r.right) < h) f = f or CR
        if (nearY && abs(p.y - r.top) < h) f = f or CT
        if (nearY && abs(p.y - r.bottom) < h) f = f or CB
        if (f == 0) {
            if (r.contains(p.x, p.y)) f = CMOVE else {
                f = CNEW
                cropAnchor = PointF(p.x.coerceIn(0f, doc.width.toFloat()), p.y.coerceIn(0f, doc.height.toFloat()))
            }
        }
        cropFlags = f
    }

    private fun cropDrag(p: PointF) {
        val r = cropRect ?: return
        val dw = doc.width.toFloat(); val dh = doc.height.toFloat()
        val dx = p.x - lastDoc.x
        val dy = p.y - lastDoc.y
        val minSize = 8f
        when {
            cropFlags == CNEW -> {
                val x = p.x.coerceIn(0f, dw); val y = p.y.coerceIn(0f, dh)
                r.set(min(cropAnchor.x, x), min(cropAnchor.y, y), max(cropAnchor.x, x), max(cropAnchor.y, y))
            }
            cropFlags == CMOVE -> {
                var ox = dx; var oy = dy
                if (r.left + ox < 0) ox = -r.left
                if (r.right + ox > dw) ox = dw - r.right
                if (r.top + oy < 0) oy = -r.top
                if (r.bottom + oy > dh) oy = dh - r.bottom
                r.offset(ox, oy)
            }
            else -> {
                if (cropFlags and CL != 0) r.left = p.x.coerceIn(0f, r.right - minSize)
                if (cropFlags and CR != 0) r.right = p.x.coerceIn(r.left + minSize, dw)
                if (cropFlags and CT != 0) r.top = p.y.coerceIn(0f, r.bottom - minSize)
                if (cropFlags and CB != 0) r.bottom = p.y.coerceIn(r.top + minSize, dh)
            }
        }
    }
}
