# PixelForge: a Photoshop-style editor for Android

Native Kotlin app, no third-party libraries. Android 7.0+ (API 24).

## Features
- **Layers and blending**: unlimited layers, opacity, visibility, 17 blend modes (Multiply, Screen, Overlay, Soft Light, Hue, Color, Luminosity...), move/transform, merge, flatten.
- **Selection and cutout**: rectangle, oval, lasso, magic wand, select brush; add/subtract/intersect; use a selection to cut out a subject or limit any edit.
- **Retouch and filters**: clone, heal, spot heal, smudge, blur, sharpen, dodge, burn, sponge, red-eye. 25 adjustments and filters, including Levels, Curves, Hue/Saturation, Exposure, Vibrance, Temperature/Tint, Gaussian and Motion Blur, Sharpen, Clarity, Noise, Vignette, Glow and Find Edges.
- **Brush, paint and text**: pressure-sensitive brush with size, hardness, opacity and smoothing; eraser, fill, gradient, shapes, eyedropper, text layers, crop.
- Import from the gallery or "Open with"/"Share to"; export PNG/JPEG/WebP.

## Build the APK

### Option A: GitHub (works from a phone)
1. Make a free repository on github.com and upload this whole folder. The hidden `.github` folder must be included. Spck Editor can import this zip and push it for you.
2. Open the repository's **Actions** tab. The "Build APK" workflow starts by itself after the push, or run it with "Run workflow".
3. When it finishes (about 5 minutes), open the run and download the **PixelForge-debug-apk** artifact. It is a zip containing `app-debug.apk`. Unzip it, then install the APK.

### Option B: Android Studio (PC)
Open this folder in Android Studio and press Run, or in a terminal run `./gradlew assembleDebug`. The APK ends up in `app/build/outputs/apk/debug/`.
